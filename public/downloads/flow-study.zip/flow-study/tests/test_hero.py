"""Hero is a true equal-scale crop of an encoded, computed field."""
import importlib
import json
import subprocess

from PIL import Image


def test_short_hero_is_a_silent_equal_scale_crop(tmp_path):
    try:
        hero = importlib.import_module("src.hero")
    except ModuleNotFoundError:
        hero = None
    assert hero is not None, "hero crop generator is missing"
    from src.render import encode
    source = tmp_path / "source.mp4"
    encode([Image.new("RGB", (1920,1080), (18,20,27)) for _ in range(3)], source)
    report = hero.create(source, tmp_path, start_frame=0, frames=3)
    assert report["crop"] == dict(x=244, y=292, width=1024, height=576)
    assert report["geometric_aspect_preserved"] is True
    path = tmp_path / "flow-hero.mp4"
    info = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-count_frames", "-show_streams", "-of", "json", str(path)]))
    assert len(info["streams"]) == 1
    stream = info["streams"][0]
    assert stream["nb_read_frames"] == "3"
    assert (stream["width"],stream["height"]) == (1920,1080)
    assert stream["sample_aspect_ratio"] == "1:1"
    assert (tmp_path / "hero-poster.webp").is_file()
