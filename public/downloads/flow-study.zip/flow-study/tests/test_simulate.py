"""Small end-to-end computation test (not a validation benchmark)."""
import importlib
import json
from pathlib import Path

import numpy as np


def test_short_run_writes_real_fields_and_finite_diagnostics(tmp_path):
    try:
        sim = importlib.import_module("src.simulate")
    except ModuleNotFoundError:
        sim = None
    assert sim is not None, "simulation runner has not been implemented"
    cfg = dict(nx=72, ny=32, cx=18, cy=16, radius=4, inlet_u=0.04,
               reynolds=30.0, seed_amplitude=0.004, start_step=20,
               stride=10, frames=4)
    sim.run(cfg, tmp_path)
    omega = np.load(tmp_path / "vorticity.npy")
    velocity = np.load(tmp_path / "velocity.npy")
    solid = np.load(tmp_path / "solid.npy")
    assert omega.shape == (4, 32, 72)
    assert velocity.shape == (4, 32, 72, 2)
    assert np.isfinite(omega[:, ~solid]).all()
    assert (omega[:, solid] == 0).all()
    assert np.max(np.abs(omega[:, ~solid])) > 0
    assert not np.array_equal(omega[0], omega[-1])
    assert (velocity[:, solid] == 0).all()
    report = json.loads((tmp_path / "numerical.json").read_text())
    assert report["sample_steps"] == [20, 30, 40, 50]
    assert report["nonfinite_count"] == 0
    assert report["rho_min"] > 0.9
    assert report["rho_max"] < 1.1
    assert abs(report["nu"] - 0.04 * 8 / 30) < 1e-14
    assert (tmp_path / "diagnostics.csv").is_file()
    assert (tmp_path / "checkpoint-final.npz").is_file()
