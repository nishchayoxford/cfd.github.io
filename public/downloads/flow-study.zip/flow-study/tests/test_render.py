"""Composition contract and real-encode smoke test."""
import importlib
from pathlib import Path
import subprocess
import json

import numpy as np
from PIL import Image


def test_renderer_encodes_actual_field_at_exact_dimensions(tmp_path):
    try:
        render = importlib.import_module("src.render")
    except ModuleNotFoundError:
        render = None
    assert render is not None, "field renderer is not implemented"
    # A manufactured field exercises signs; production never uses this fixture.
    y, x = np.indices((32, 72), dtype=float)
    omega = (x - 36) / 36
    solid = ((x - 18) ** 2 + (y - 16) ** 2) <= 16
    cfg = dict(nx=72, ny=32, cx=18, cy=16, radius=4, inlet_u=.04,
               reynolds=30, frames=3, start_step=20, stride=10)
    rows = [dict(t_star=i, probe_uy_over_u=np.sin(i), step=20+i*10) for i in range(3)]
    composer = render.Composer(cfg, rows)
    frames = [composer.frame(omega, solid, i) for i in range(3)]
    assert all(im.size == (1920, 1080) and im.mode == "RGB" for im in frames)
    # All visible text boxes must remain on the canvas and not collide.
    boxes = composer.text_boxes
    for box in boxes:
        assert 0 <= box[0] < box[2] <= 1920
        assert 0 <= box[1] < box[3] <= 1080
    for i, a in enumerate(boxes):
        for b in boxes[i+1:]:
            overlap_x = min(a[2], b[2]) - max(a[0], b[0])
            overlap_y = min(a[3], b[3]) - max(a[1], b[1])
            assert overlap_x <= 0 or overlap_y <= 0
    path = tmp_path / "test.mp4"
    render.encode(frames, path, fps=30)
    probe = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-count_frames", "-show_streams", "-of", "json", str(path)]))
    stream = probe["streams"][0]
    assert (stream["width"], stream["height"]) == (1920, 1080)
    assert stream["codec_name"] == "h264"
    assert stream["pix_fmt"] == "yuv420p"
    assert stream["sample_aspect_ratio"] == "1:1"
    assert stream["nb_read_frames"] == "3"
    assert stream["r_frame_rate"] == "30/1"


def test_probe_chart_does_not_clip_computed_extrema():
    from src.render import Composer
    cfg = dict(nx=72, ny=32, cx=18, cy=16, radius=4, inlet_u=.04,
               reynolds=30, frames=3, start_step=20, stride=10)
    rows = [dict(t_star=i, probe_uy_over_u=u, step=i) for i, u in enumerate([0, -.6534, .7084])]
    composer = Composer(cfg, rows)
    assert hasattr(composer, "probe_coordinates"), "unclipped probe-coordinate mapping is missing"
    points = composer.probe_coordinates(2)
    # A fixed ±1 full-scale mapping leaves the observed extrema inside the chart.
    np.testing.assert_allclose(points[:, 1], 977 - np.array([0, -.6534, .7084]) * 25)
    assert (points[:, 1] > 950).all() and (points[:, 1] < 1004).all()
