"""Release verification must reject a merely plausible media file."""
import importlib

import pytest


def test_media_contract_rejects_wrong_dimensions():
    try:
        verify = importlib.import_module("src.verify")
    except ModuleNotFoundError:
        verify = None
    assert verify is not None, "release media validation is missing"
    stream = dict(codec_name="h264", pix_fmt="yuv420p", width=1918, height=1080,
                  r_frame_rate="30/1", avg_frame_rate="30/1", sample_aspect_ratio="1:1",
                  nb_read_frames="720", duration="24.000000")
    with pytest.raises(AssertionError):
        verify.check_stream(stream, frames=720, fps=30)
    stream["width"] = 1920
    verify.check_stream(stream, frames=720, fps=30)
    stream["nb_read_frames"] = "719"
    with pytest.raises(AssertionError):
        verify.check_stream(stream, frames=720, fps=30)


def test_independent_numerical_consistency_checks():
    try:
        verify = importlib.import_module("src.verify")
    except ModuleNotFoundError:
        verify = None
    assert verify is not None and hasattr(verify, "numerical_sanity"), "numerical audit is missing"
    report = verify.numerical_sanity()
    assert report["periodic_mass_relative_error"] < 1e-12
    assert report["shear_decay_relative_error"] < 0.01
    assert report["shear_decay_measured"] < 1
