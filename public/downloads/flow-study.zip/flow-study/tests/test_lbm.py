"""Unit tests for the standalone numerical demonstration."""
import importlib

import numpy as np
import pytest


def load_lbm():
    try:
        return importlib.import_module("src.lbm")
    except ModuleNotFoundError:
        return None


def test_equilibrium_recovers_density_and_momentum():
    lbm = load_lbm()
    assert lbm is not None, "D2Q9 equilibrium API is not implemented"
    rho = np.full((3, 4), 1.2)
    ux = np.full_like(rho, 0.04)
    uy = np.full_like(rho, -0.02)
    f = lbm.equilibrium(rho, ux, uy)
    assert f.shape == (3, 4, 9)
    np.testing.assert_allclose(f.sum(axis=-1), rho, atol=1e-14)
    np.testing.assert_allclose(f @ lbm.C[:, 0], rho * ux, atol=1e-14)
    np.testing.assert_allclose(f @ lbm.C[:, 1], rho * uy, atol=1e-14)
    # Rest population: w0 rho [1 - (3/2) |u|^2].
    np.testing.assert_allclose(f[..., 0], (4 / 9) * 1.2 * (1 - 1.5 * 0.002))


@pytest.mark.parametrize("inlet,obstacle,open_x", [(0.06, False, True), (0.0, True, False)])
def test_stream_collide_preserves_steady_equilibrium(inlet, obstacle, open_x):
    lbm = load_lbm()
    assert hasattr(lbm, "advance"), "stream/collide and boundaries are missing"
    rho = np.ones((18, 42))
    f = lbm.equilibrium(rho, np.full_like(rho, inlet), np.zeros_like(rho))
    original = f.copy()
    solid = np.zeros(rho.shape, dtype=np.bool_)
    if obstacle:
        y, x = np.indices(rho.shape)
        solid = ((x - 10) ** 2 + (y - 9) ** 2) <= 9
    f = lbm.advance(f, solid, tau=0.57, inlet_u=inlet, steps=25, open_x=open_x)
    np.testing.assert_allclose(f[~solid], original[~solid], atol=2e-14)


def test_macroscopic_curl_has_positive_sign_for_counterclockwise_rotation():
    lbm = load_lbm()
    assert hasattr(lbm, "macroscopic") and hasattr(lbm, "curl"), "field extraction missing"
    y, x = np.indices((15, 13), dtype=float)
    a = 0.002
    ux = -a * (y - 7)
    uy = a * (x - 6)
    f = lbm.equilibrium(np.ones_like(x), ux, uy)
    rho, measured_x, measured_y = lbm.macroscopic(f, np.zeros_like(x, dtype=bool))
    np.testing.assert_allclose(rho, 1, atol=1e-14)
    np.testing.assert_allclose(measured_x, ux, atol=1e-14)
    np.testing.assert_allclose(measured_y, uy, atol=1e-14)
    omega = lbm.curl(measured_x, measured_y)
    np.testing.assert_allclose(omega[1:-1, 1:-1], 2 * a, atol=1e-14)
