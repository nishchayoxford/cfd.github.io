# The wake comes alive

An original, standalone **computed** CFD showcase. The film shows a two-dimensional D2Q9/BGK lattice-Boltzmann cylinder wake at nominal **Re = 120**, flowing left to right. Cyan is negative (clockwise) vorticity; coral is positive (counterclockwise).

**Standalone numerical demonstration — not validated research.** This is a modest-resolution educational calculation, not an experiment, a thesis result, a turbulence model, or evidence of engineering accuracy. No external simulation data, research assets, stock footage, generative-video assets, or website-template author imagery were used.

## Compact reproduction package

This archive contains the actual solver, rendering/verification code, all ten source tests, pinned Python dependencies, complete configuration and production fonts with licenses. `evidence/` contains the original numerical report, all 720 diagnostic rows, render/crop contracts and a public verification extract. Machine-specific execution timings are omitted from the reference JSON. No environment, cache, raw field arrays, checkpoint, execution log or finished film is bundled. All fields are recomputed from the bundled configuration; no external simulation source is needed.

## Generated artifacts (not bundled)

All paths below are relative to this directory.

| Artifact | Path | Contract |
|---|---|---|
| Main film | `output/flow-film.mp4` | 1920×1080, 24.000 s, 720 frames, 30 fps, H.264 High, yuv420p, SAR 1:1, silent, faststart |
| Main poster | `output/flow-poster.webp` | 1920×1080; numerical frame 570, t* ≈ 67.69 |
| Lossless poster | `output/flow-poster.png` | Same composition and numerical frame |
| Optional hero | `output/flow-hero.mp4` | 1920×1080, 10.000 s, 300 frames, 30 fps, silent; a real equal-scale crop |
| Hero poster | `output/hero-poster.webp` | Extracted from the encoded hero |
| Encoded frame contact sheet | `output/encoded-contact-sheet.png` | Actual decoded frames 0, 360 and 719 |
| Full decoded frame audits | `output/encoded-start.png`, `encoded-middle.png`, `encoded-end.png` | From the final MP4, not source renders |
| Technical verification | `output/verification-manifest.json` | ffprobe, numerical diagnostics, checks, SHA-256 inventory |
| Rendering / crop contracts | `output/render.json`, `output/hero.json` | Sampling, range, source-frame and geometry details |

The verification manifest is authoritative after reproduction; encoded byte sizes can vary with FFmpeg. The main film has a 12 MB size check. The hero covers source frames 360–659 (12–22 seconds of the main film). It is chronological, **not promised to be a seamless loop**.

## Reproduce

Prerequisites: Linux/macOS, Python 3.12, `uv`, and `ffmpeg`/`ffprobe` with libx264. The reference run used Python 3.12.3 and FFmpeg 6.1.1; the lockfile pins Python packages, not system libraries. Fonts are bundled with their OFL licenses, so rendering needs no network after dependency installation. Linux is tested; the path-independent commands are intended for macOS too, but that platform was not exercised. Allow at least 3 GB free disk space. No GPU is required.

```bash
unzip flow-study.zip
cd flow-study
bash reproduce.sh
```

The script uses `uv` on PATH (or an explicit `UV_BIN`), creates a local `.venv`, installs pinned transitive dependencies, executes tests, computes the flow, renders both films and posters, and verifies the actual encoded outputs. It writes within the extracted project apart from package-manager caches. Progress is printed every 30 simulation snapshots and 60 rendered frames. Do not run Python with `-O`: verification uses assertions.

After a successful full run, regenerate visuals from the newly computed arrays without recomputing the solver (this is **not** a first-run command):

```bash
bash reproduce.sh render-only
```

Alternatively, from inside the extracted `flow-study` folder, without uv:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
mkdir -p logs data output .scratch
export TMPDIR="$PWD/.scratch"
.venv/bin/python -m pytest tests -q --junitxml=logs/tests.xml
OPENBLAS_NUM_THREADS=1 .venv/bin/python -m src.simulate --config config.json --output data
.venv/bin/python -m src.render
.venv/bin/python -m src.hero
.venv/bin/python -m src.verify
```

The solver is serial compiled Numba; encoding uses four threads. The generated float32 vorticity and velocity arrays total **1,300,561,920 bytes** before NPY headers. Calculations and the final checkpoint use float64. Small CPU/platform differences can change floating-point or encoded bytes; the numerical and media-contract checks matter more than cross-platform byte identity. `python -m pytest tests -q` includes a small real solver run and actual H.264/hero smoke encodes, but it does not replace the full default-config reproduction above.

## Method

### Governing approximation

The isothermal, weakly compressible D2Q9 lattice-Boltzmann BGK method approximates incompressible Navier–Stokes behavior at low Mach number. Lattice spacings are dx = dt = 1 and c_s² = 1/3.

```text
f_eq_i = w_i rho [1 + 3(c_i · u) + (9/2)(c_i · u)^2 - (3/2)|u|^2]
f_i(x + c_i, t + 1) = f_i(x, t) - (1/tau) [f_i(x, t) - f_eq_i(x, t)]
rho = sum_i f_i
rho u = sum_i c_i f_i
nu = (tau - 1/2) / 3
Re = U_in D / nu
omega_z = du_y/dx - du_x/dy
omega* = omega_z D / U_in
t* = t U_in / D
```

D2Q9 ordering is `(0,0), (1,0), (0,1), (-1,0), (0,-1), (1,1), (-1,1), (-1,-1), (1,-1)`. Weights are 4/9 at rest, 1/9 on axial links and 1/36 on diagonals. Positive y is upward. The renderer flips the array vertically exactly once; it does not reverse the sign of vorticity.

### Executed case

| Parameter | Value |
|---|---:|
| Grid | 672 × 224 nodes |
| Nominal cylinder centre | (104, 112) lattice units |
| Nominal cylinder radius / diameter | 14 / 28 nodes |
| Inlet velocity U_in | 0.065 lattice units |
| Nominal Reynolds number | 120 |
| Kinematic viscosity | 0.015166666666666667 |
| BGK relaxation time | 0.5455 |
| Solid cells / fluid cells | 613 / 149,915 |
| Steps computed | 36,312 |
| Retained sample steps | 1,800 + 48i, i = 0,…,719 |
| Displayed dimensionless times | t* = 4.178571… to 84.295714… |

The initial density is one and the fluid starts with uniform x velocity. A **single deterministic initial transverse velocity perturbation**, at most 1% of U_in, is a Gaussian near the cylinder; its exact formula is in `src/simulate.py`. It breaks reflection symmetry. It is not a time-varying forcing and does not prescribe the later wake. All subsequent vortices emerge from repeated streaming, collision and boundary conditions. This is not a collection of analytically invented vortices.

### Boundaries and differentiation

- Left: Zou–He fixed-velocity inlet, u_x = U_in, u_y = 0; density reconstructed from incoming populations.
- Right: first-order zero-gradient extrapolation of incoming populations. It is simple, not a reflection-free outlet.
- Top/bottom: periodic boundaries, **not solid channel walls and not an isolated unbounded cylinder**. The finite transverse period gives a periodic array/blockage effect.
- Cylinder: stationary link bounce-back on a stair-stepped binary solid mask. No interpolated curved-wall correction.
- Vorticity: second-order centered finite differences, periodic in y and second-order one-sided at x boundaries. Velocities are set to zero within solids; near-wall gradients therefore retain grid/discrete-wall effects. No filtering of the computed vorticity is applied.

The cylinder's nominal circle is outlined for readability, but the actual discrete solid mask occludes the field. The visualization preserves equal x/y geometric scale. There is no obstacle stretching or fabricated trajectory.

## Visualization contract

- Dark visual tokens: `#12141b`, `#1a1d26`, `#2c3040`; heading `#e8eaf0`, body `#aeb3c2`, accent `#8b95f0`.
- Negative vorticity: cyan `#69d3d3`; positive vorticity: coral `#f2a38c`.
- One **fixed, linear, symmetric** range −3 to +3 for omega*. Higher magnitudes are clipped **in the display only**, clearly labelled. At most 0.714% of fluid pixels are clipped in the executed series; unsaturated raw values remain in `data/vorticity.npy` and diagnostics.
- Fine lines are real isovorticity contours at increments of 0.5, not decorative streamlines. RGB is bilinearly interpolated through the scalar field for presentation; this adds no physical resolution.
- The main domain occupies 1728×576 display pixels; both axes use the same factor. The main poster uses frame 570 from the same data.
- The white downstream marker is the actual probe cell `(244,112)`. Its progressively revealed history is measured u_y/U_in, with a fixed ±1 ordinate range and **no clipping**. It is not a trajectory or force coefficient.
- Each movie frame is a computed snapshot, every 48 simulation steps. There is **no temporal field interpolation**, repeated endpoint, cross-fade, synthetic swirl, or analytically animated substitute. Frames represent interval starts; frame 719 is at video timestamp 719/30 seconds, and the MP4 duration is 24 seconds.
- Fonts: bundled Space Grotesk and JetBrains Mono, OFL licensed. Original composition and code; no template-author images or films.
- The hero is an equal-aspect 1024×576 pixel crop of the encoded main field, scaled to 1920×1080. The caveat is retained in a readable overlay. The enlarged stair-stepped boundary is intentional evidence of finite-grid resolution.

## Verification and honest limitations

`src/verify.py` inspects the **encoded** media using `ffprobe -count_frames`, decodes each MP4 completely, checks duration/rate/frame count/codec/pixel format/SAR, asserts the main file fits 12 MB, extracts exact start/middle/end frames and builds the contact sheet. It checks poster provenance against decoded frame 570 and verifies text bounds and text-to-text overlaps at representative frames.

It also checks every retained raw array for non-finite values and solid masking, verifies that every consecutive field changes, and measures positive downstream translation of the mature wake by field correlation. Three audited intervals each move approximately 15 lattice nodes rightward across 240 steps, with correlations above 0.997. This is a field-motion check, **not a material-particle velocity measurement**.

Observed diagnostics:

- No non-finite retained values or populations; minimum population 0.0188072.
- Density range: **0.987929–1.013584**.
- Maximum local Mach number: **0.16938**.
- Maximum total fluid-mass change from initial: **0.08441%**. This is an **open system**, so this number is not a closed-domain conservation claim.
- Maximum instantaneous inlet/outlet flux imbalance: **1.823%**, including transients.
- Maximum dimensionless interior RMS divergence: **0.03814**, excluding three solid-adjacent layers and three inlet/outlet columns. The scheme is weakly compressible, not an exact projection-based incompressible solver.
- The unsaturated vorticity range reaches approximately **−18.46 to +18.46** near the discrete wall, well beyond the display range.

Two independent low-cost consistency checks exercise the same kernel:

1. Periodic-domain mass conservation with a solid obstacle: relative error **7.1×10⁻¹⁵** over 100 steps.
2. A periodic sinusoidal shear mode decays at the expected viscous rate: measured ratio 0.840219 versus analytical 0.840726 after 180 steps, a relative discrepancy of **0.0603%**.

These are implementation/consistency checks, **not research validation**. No grid, time-step or domain-size convergence study; no drag/lift force validation; no experimental comparison; no 3-D instability, turbulence or free-surface model; no claim of a validated Strouhal number. The finite periodic cross-section, approximate outlet, stair-stepped boundary, startup acoustic transients, moderate local Mach number and BGK relaxation near 0.5 all limit quantitative accuracy. The visible early-time inlet ripples are retained rather than hidden. The film is suitable for explaining a numerical workflow, not for design decisions.

### Tests and audit trail

Ten tests cover equilibrium moments, steady uniform/open-boundary preservation, rest/bounce-back preservation, signed curl, a small real computation, exact real H.264 encoding and typography bounds, unclipped probe extrema, rejection of bad media contracts, conservation/decay checks, and the hero's real equal-scale encode.

The probe chart's first draft clipped measured peaks; the retained regression fixture protects the corrected range. Reproduction creates new logs and SHA-256 fingerprints for the arrays, checkpoint, configuration, sources, fonts and outputs. `evidence/reference-verification.json` is explicitly a historical public extract, not a new verification of a reader's run. The verifier expects the unchanged 720-frame production configuration; use the source tests for low-cost smoke checks rather than passing a shortened run to the full-film verifier.

## Source layout

```text
src/lbm.py        D2Q9 equilibrium, fused stream/collide, boundaries, curl
src/simulate.py   Deterministic run, field snapshots, checkpoint, diagnostics
src/render.py     Original composition, fixed colour scale, streaming H.264
src/hero.py       Chronological near-wake crop and scientific overlay
src/verify.py     Numerical consistency, media decode, provenance manifest
config.json      Executed numerical configuration
requirements.txt Direct pinned dependencies
requirements.lock.txt  All installed dependencies pinned
reproduce.sh     End-to-end or render-only runner
assets/          Bundled fonts and OFL notices
evidence/        Compact reference diagnostics and public verification extract
MANIFEST.sha256.json  Hashes of all other distributed files
logs/            Created by reproduction; not distributed
data/            Created arrays, checkpoint, numerical report and CSV; not distributed
output/          Created films, posters, decoded audits and manifest; not distributed
```

Array orientation: `vorticity.npy[frame,y,x]` stores omega*; `velocity.npy[frame,y,x,component]` stores lattice velocity with components x then y. `solid.npy[y,x]` is true inside the discrete cylinder. Time, density, population positivity, enstrophy, flux, divergence and probe quantities are in `data/diagnostics.csv`.

### Font provenance

Downloaded directly from the public Google Fonts repository, not from a website template:

- `https://raw.githubusercontent.com/google/fonts/main/ofl/spacegrotesk/SpaceGrotesk%5Bwght%5D.ttf`
- `https://raw.githubusercontent.com/google/fonts/main/ofl/spacegrotesk/OFL.txt`
- `https://raw.githubusercontent.com/google/fonts/main/ofl/jetbrainsmono/JetBrainsMono%5Bwght%5D.ttf`
- `https://raw.githubusercontent.com/google/fonts/main/ofl/jetbrainsmono/OFL.txt`

The bundled byte-identical fonts are bound by manifest hashes. Code and original media composition are released under the accompanying MIT license; bundled font licenses remain separate.
