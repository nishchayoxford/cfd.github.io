#!/usr/bin/env bash
# Reproduce the standalone calculation and/or its actual encoded media.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
UV_BIN="${UV_BIN:-uv}"
export UV_CACHE_DIR="$PWD/.uv-cache"
export TMPDIR="$PWD/.scratch"
export OPENBLAS_NUM_THREADS=1
mkdir -p logs output data "$TMPDIR"
if [[ ! -x .venv/bin/python ]]; then
  "$UV_BIN" venv --python 3.12 .venv
fi
"$UV_BIN" pip install --python .venv/bin/python -r requirements.lock.txt
.venv/bin/python -m pytest tests -q --junitxml=logs/tests.xml | tee logs/tests.txt
case "${1:-all}" in
  all) .venv/bin/python -m src.simulate --config config.json --output data | tee logs/simulation.log ;;
  render-only) test -f data/numerical.json && test -f data/vorticity.npy ;;
  *) printf 'Usage: %s [all|render-only]\n' "$0" >&2; exit 2 ;;
esac
.venv/bin/python -m src.render | tee logs/render.log
.venv/bin/python -m src.hero | tee logs/hero.txt
.venv/bin/python -m src.verify | tee logs/verification.txt
