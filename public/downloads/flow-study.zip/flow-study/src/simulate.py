"""Run a deterministic, standalone cylinder-wake calculation.

Usage: python -m src.simulate --config config.json --output data
The renderer reads these computed arrays; it does not invent flow fields.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import time

import numpy as np
from scipy.ndimage import binary_dilation

from .lbm import advance, curl, equilibrium, macroscopic


def run(cfg, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    nx, ny = cfg["nx"], cfg["ny"]
    radius = cfg["radius"]
    diameter = 2.0 * radius
    u = cfg["inlet_u"]
    nu = u * diameter / cfg["reynolds"]
    tau = 0.5 + 3 * nu
    if not (tau > 0.5 and u < 0.12 and cfg["stride"] > 0):
        raise ValueError("Need tau > .5, subsonic inlet_u < .12, positive stride")
    y, x = np.indices((ny, nx))
    solid = ((x - cfg["cx"]) ** 2 + (y - cfg["cy"]) ** 2) <= radius ** 2
    fluid = ~solid
    interior = ~binary_dilation(solid, iterations=3)
    interior[:, :3] = False
    interior[:, -3:] = False
    # A small, deterministic initial velocity seed breaks reflection symmetry.
    # It is only an initial condition; all subsequent fields are computed.
    ux = np.full((ny, nx), u)
    uy = cfg["seed_amplitude"] * u * np.exp(
        -((x - cfg["cx"] - 2 * radius) / (2 * radius)) ** 2
        -((y - cfg["cy"]) / (2 * radius)) ** 2)
    ux[solid] = uy[solid] = 0
    f = equilibrium(np.ones((ny, nx)), ux, uy)
    total_initial_mass = float(f.sum(axis=-1)[fluid].sum())
    np.save(output / "solid.npy", solid)
    frames = cfg["frames"]
    omega_out = np.lib.format.open_memmap(output / "vorticity.npy", mode="w+",
                                          dtype="float32", shape=(frames, ny, nx))
    velocity_out = np.lib.format.open_memmap(output / "velocity.npy", mode="w+",
                                             dtype="float32", shape=(frames, ny, nx, 2))
    rows = []
    started = time.monotonic()
    current = 0
    nonfinite = 0
    px = min(nx - 4, int(cfg["cx"] + 5 * diameter))
    py = cfg["cy"]
    for frame in range(frames):
        target = cfg["start_step"] + frame * cfg["stride"]
        f = advance(f, solid, tau, u, target - current, True)
        current = target
        rho, ux, uy = macroscopic(f, solid)
        omega = curl(ux, uy) * diameter / u
        omega[solid] = 0
        invalid = np.size(f) - np.count_nonzero(np.isfinite(f))
        nonfinite += int(invalid)
        if invalid or float(rho[fluid].min()) <= 0:
            raise FloatingPointError(f"Nonfinite/negative-density state at step {target}")
        omega_out[frame] = omega
        velocity_out[frame, ..., 0] = ux
        velocity_out[frame, ..., 1] = uy
        speed = np.hypot(ux, uy)
        divergence = np.gradient(ux, axis=1, edge_order=2) + (
            np.roll(uy, -1, axis=0) - np.roll(uy, 1, axis=0)) * 0.5
        flux_in = float(np.sum(rho[:, 0] * ux[:, 0]))
        flux_out = float(np.sum(rho[:, -1] * ux[:, -1]))
        rows.append(dict(frame=frame, step=target, t_star=target * u / diameter,
                         mass=float(rho[fluid].sum()), rho_min=float(rho[fluid].min()),
                         rho_max=float(rho[fluid].max()), min_population=float(f.min()),
                         speed_max=float(speed.max()), mach_max=float(speed.max() * np.sqrt(3)),
                         omega_min=float(omega[fluid].min()), omega_max=float(omega[fluid].max()),
                         omega_p99_abs=float(np.percentile(np.abs(omega[fluid]), 99)),
                         enstrophy_mean=float(np.mean(omega[fluid] ** 2) / 2),
                         divergence_rms_star=float(np.sqrt(np.mean(divergence[interior] ** 2)) * diameter / u),
                         probe_uy_over_u=float(uy[py, px] / u),
                         flux_in=flux_in, flux_out=flux_out,
                         flux_imbalance_fraction=(flux_in - flux_out) / flux_in))
        if frame % 30 == 0 or frame == frames - 1:
            elapsed = time.monotonic() - started
            print(f"CFD {frame + 1:4d}/{frames}: step={target}, t*={target*u/diameter:.2f}, "
                  f"rho=[{rho[fluid].min():.5f},{rho[fluid].max():.5f}], "
                  f"|omega*|max={np.max(np.abs(omega)):.2f}; {elapsed:.1f}s", flush=True)
            omega_out.flush()
            velocity_out.flush()
    omega_out.flush()
    velocity_out.flush()
    np.savez_compressed(output / "checkpoint-final.npz", f=f, solid=solid,
                        step=current, config_json=json.dumps(cfg, sort_keys=True))
    with (output / "diagnostics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    report = dict(config=cfg, nu=nu, tau=tau, cs2=1/3, units="lattice dx=dt=1",
                  field_quantity="omega_z D / U_in = (du_y/dx - du_x/dy) D / U_in",
                  field_storage="float32; calculations and checkpoint float64",
                  sample_steps=[r["step"] for r in rows],
                  t_star_range=[rows[0]["t_star"], rows[-1]["t_star"]],
                  fluid_cells=int(fluid.sum()), solid_cells=int(solid.sum()),
                  nonfinite_count=nonfinite,
                  rho_min=min(r["rho_min"] for r in rows),
                  rho_max=max(r["rho_max"] for r in rows),
                  mach_max=max(r["mach_max"] for r in rows),
                  population_min=min(r["min_population"] for r in rows),
                  omega_min=min(r["omega_min"] for r in rows),
                  omega_max=max(r["omega_max"] for r in rows),
                  maximum_relative_mass_change_from_initial=max(abs(r["mass"]/total_initial_mass - 1) for r in rows),
                  mass_note="Open system: density transients and net inlet/outlet flux change total mass.",
                  maximum_abs_flux_imbalance=max(abs(r["flux_imbalance_fraction"]) for r in rows),
                  divergence_rms_star_max=max(r["divergence_rms_star"] for r in rows),
                  probe=dict(x_lattice=px, y_lattice=py, quantity="u_y/U_in"),
                  elapsed_seconds=time.monotonic() - started,
                  boundaries="Zou-He velocity inlet; first-order population extrapolation outlet; periodic y; link bounce-back cylinder",
                  status="Standalone numerical demonstration — not validated research")
    (output / "numerical.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--output", default="data")
    args = parser.parse_args()
    run(json.loads(Path(args.config).read_text()), args.output)
