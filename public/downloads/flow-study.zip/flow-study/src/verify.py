"""Verify encoded assets, numerical consistency, provenance and layout.

This is a numerical/technical audit, not experimental or research validation.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .lbm import advance, equilibrium, macroscopic
from .render import Composer

ROOT = Path(__file__).resolve().parents[1]


def check_stream(stream, frames, fps):
    assert stream["codec_name"] == "h264"
    assert stream["pix_fmt"] == "yuv420p"
    assert (stream["width"], stream["height"]) == (1920, 1080)
    assert stream["sample_aspect_ratio"] == "1:1"
    assert Fraction(stream["r_frame_rate"]) == fps
    assert Fraction(stream["avg_frame_rate"]) == fps
    assert int(stream["nb_read_frames"]) == frames
    assert abs(float(stream["duration"]) - frames / fps) < 1e-5


def numerical_sanity():
    """Independent closed-domain conservation and viscous-decay checks."""
    y, x = np.indices((32, 64))
    rho = 1 + 0.0001 * np.cos(2 * np.pi * x / 64)
    solid = ((x - 16)**2 + (y - 16)**2) <= 16
    ux = 0.002 * np.sin(2 * np.pi * y / 32)
    uy = np.zeros_like(ux)
    ux[solid] = 0
    f = equilibrium(rho, ux, uy)
    before = float(f.sum(axis=-1)[~solid].sum())
    f = advance(f, solid, 0.8, 0.0, 100, False)
    after = float(f.sum(axis=-1)[~solid].sum())
    mass_error = abs(after / before - 1)
    y, x = np.indices((64, 24))
    mode = np.sin(2 * np.pi * y / 64)
    ux = .001 * mode
    solid = np.zeros_like(x, dtype=bool)
    f = equilibrium(np.ones_like(ux), ux, np.zeros_like(ux))
    tau, steps = .8, 180
    f = advance(f, solid, tau, 0.0, steps, False)
    _, vx, _ = macroscopic(f, solid)
    ratio = float(np.sum(vx * mode) / np.sum(ux * mode))
    nu = (tau - .5) / 3
    expected = float(np.exp(-nu * (2 * np.pi / 64)**2 * steps))
    decay_error = abs(ratio / expected - 1)
    assert mass_error < 1e-12
    assert decay_error < .01
    return dict(periodic_mass_relative_error=mass_error,
                shear_decay_measured=ratio, shear_decay_expected=expected,
                shear_decay_relative_error=decay_error,
                shear_case=dict(ny=64, nx=24, tau=tau, nu=nu, steps=steps,
                                initial_amplitude=.001),
                interpretation="Consistency checks only; not cylinder-wake validation")


def ffprobe(path):
    result = subprocess.check_output([
        "ffprobe", "-v", "error", "-count_frames", "-show_streams",
        "-show_format", "-of", "json", str(path)], text=True)
    return json.loads(result)


def extract_frame(path, index, target):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(path),
                    "-vf", f"select=eq(n\\,{index})", "-fps_mode", "vfr",
                    "-frames:v", "1", str(target)], check=True)
    return Image.open(target).convert("RGB")


def run(root=ROOT):
    root = Path(root)
    output = root / "output"
    data = root / "data"
    numerical = json.loads((data / "numerical.json").read_text())
    cfg = numerical["config"]
    main = output / "flow-film.mp4"
    probe = ffprobe(main)
    video = [s for s in probe["streams"] if s["codec_type"] == "video"]
    assert len(video) == 1 and len(probe["streams"]) == 1, "Expected a single silent video stream"
    check_stream(video[0], cfg["frames"], 30)
    assert main.stat().st_size <= 12_000_000
    # A complete decode catches corruption that header inspection would miss.
    subprocess.run(["ffmpeg", "-v", "error", "-i", str(main), "-f", "null", "-"], check=True)
    body = main.read_bytes()
    faststart = body.find(b"moov") < body.find(b"mdat")
    assert faststart
    frames = cfg["frames"]
    indices = [0, frames // 2, frames - 1]
    images = []
    for index, name in zip(indices, ["start", "middle", "end"]):
        image = extract_frame(main, index, output / f"encoded-{name}.png")
        assert image.size == (1920, 1080)
        images.append(image)
    sheet = Image.new("RGB", (1920, 440), (18, 20, 27))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype(str(root / "assets" / "JetBrainsMono.ttf"), 20)
    draw.text((22, 12), "ENCODED FRAME AUDIT  /  START · MIDDLE · END", font=font, fill=(174,179,194))
    for i, (image, index) in enumerate(zip(images, indices)):
        sheet.paste(image.resize((640, 360), Image.Resampling.LANCZOS), (i*640, 48))
        t_star = (cfg["start_step"] + index*cfg["stride"]) * cfg["inlet_u"] / (2*cfg["radius"])
        draw.text((22+i*640, 413), f"FRAME {index:03d} · {index/30:.3f}s · t* {t_star:.2f}",
                  font=font, fill=(174,179,194))
    sheet.save(output / "encoded-contact-sheet.png")
    poster = Image.open(output / "flow-poster.webp").convert("RGB")
    assert poster.size == (1920, 1080)
    encoded_poster = extract_frame(main, 570, output / "encoded-poster.png")
    poster_mae = float(np.mean(np.abs(np.array(encoded_poster, dtype=float) - np.array(poster, dtype=float))))
    assert poster_mae < 8

    omega = np.load(data / "vorticity.npy", mmap_mode="r")
    velocity = np.load(data / "velocity.npy", mmap_mode="r")
    solid = np.load(data / "solid.npy")
    assert omega.shape == (frames, cfg["ny"], cfg["nx"])
    assert velocity.shape == (*omega.shape, 2)
    nonfinite = 0
    changed = []
    clipped_fraction = []
    for i in range(frames):
        nonfinite += int(np.count_nonzero(~np.isfinite(omega[i])))
        nonfinite += int(np.count_nonzero(~np.isfinite(velocity[i])))
        assert np.all(omega[i][solid] == 0)
        assert np.all(velocity[i][solid] == 0)
        clipped_fraction.append(float(np.mean(np.abs(omega[i][~solid]) > 3)))
        if i:
            changed.append(float(np.mean(np.abs(omega[i] - omega[i-1]))))
    assert nonfinite == 0
    assert min(changed) > 0
    assert numerical["rho_min"] > .95 and numerical["rho_max"] < 1.05
    assert numerical["population_min"] > 0
    assert numerical["mach_max"] < .2
    # Eulerian field correlation checks that mature structures move rightward.
    advection = []
    for index in [420, 510, 600]:
        earlier = np.asarray(omega[index, 30:-30, 260:490], dtype=float)
        scores = []
        shifts = np.arange(-30, 31)
        for shift in shifts:
            later = np.asarray(omega[index+5, 30:-30, 260+shift:490+shift], dtype=float)
            scores.append(float(np.sum(earlier*later) / np.sqrt(np.sum(earlier**2)*np.sum(later**2))))
        best = int(np.argmax(scores))
        advection.append(dict(start_frame=index, frame_gap=5,
                              shift_x_lattice=int(shifts[best]), correlation=scores[best],
                              estimated_speed_lattice=float(shifts[best]/(5*cfg["stride"]))))
    assert all(item["shift_x_lattice"] > 0 for item in advection)
    with (data / "diagnostics.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == frames
    expected_steps = [cfg["start_step"]+i*cfg["stride"] for i in range(frames)]
    assert [int(r["step"]) for r in rows] == expected_steps
    # Inspect every distinct text layout (all labels change only in width).
    composer = Composer(cfg, rows)
    for i in [0, 360, 570, 719]:
        composer.frame(omega[i], solid, i)
        boxes = composer.text_boxes
        for a in boxes:
            assert 0 <= a[0] < a[2] <= 1920 and 0 <= a[1] < a[3] <= 1080
        for j, a in enumerate(boxes):
            for b in boxes[j+1:]:
                assert min(a[2], b[2]) <= max(a[0], b[0]) or min(a[3], b[3]) <= max(a[1], b[1])
    points = composer.probe_coordinates(frames-1)
    assert np.min(points[:,1]) > 950 and np.max(points[:,1]) < 1004
    hero_probe = None
    if (output / "flow-hero.mp4").exists():
        hero_probe = ffprobe(output / "flow-hero.mp4")
        check_stream(hero_probe["streams"][0], 300, 30)
        assert len(hero_probe["streams"]) == 1
        subprocess.run(["ffmpeg", "-v", "error", "-i", str(output / "flow-hero.mp4"),
                        "-f", "null", "-"], check=True)
    test_summary = None
    if (root / "logs" / "tests.xml").exists():
        suites = ET.parse(root / "logs" / "tests.xml").getroot()
        test_summary = [dict(s.attrib) for s in suites.findall("testsuite")]
        assert all(int(s["failures"]) == 0 and int(s["errors"]) == 0 for s in test_summary)
    paths = sorted(set(
        list((root / "src").glob("*.py")) + list((root / "tests").glob("*.py"))
        + list((root / "assets").glob("*"))
        + [p for p in output.glob("*") if p.name != "verification-manifest.json" and not p.name.startswith("preview-")]
        + [data / "vorticity.npy", data / "velocity.npy", data / "solid.npy",
           data / "checkpoint-final.npz", data / "numerical.json", data / "diagnostics.csv"]
        + [p for p in [root / "config.json", root / "requirements.txt", root / "requirements.lock.txt",
                        root / "README.md", root / "LICENSE", root / "reproduce.sh"] if p.exists()]
    ))
    inventory = {}
    for path in paths:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(1024*1024):
                digest.update(chunk)
        inventory[str(path.relative_to(root))] = dict(bytes=path.stat().st_size, sha256=digest.hexdigest())
    manifest = dict(schema_version=1, status="PASS", kind="Technical and numerical-consistency audit",
                    caveat="Standalone numerical demonstration, not validated research. No convergence or experimental validation.",
                    environment=dict(python=sys.version, platform=platform.platform(),
                                     dependencies={name: importlib.metadata.version(name) for name in ["numpy","numba","scipy","pillow","pytest"]},
                                     ffmpeg=subprocess.check_output(["ffmpeg","-version"], text=True).splitlines()[0]),
                    main_video_ffprobe=probe, hero_ffprobe=hero_probe,
                    full_decode="PASS", faststart=faststart,
                    size_budget_bytes=12_000_000,
                    poster=dict(dimensions=list(poster.size), source_frame=570, encoded_mean_abs_rgb_difference=poster_mae),
                    encoded_contact_sheet=dict(indices=indices, file="output/encoded-contact-sheet.png"),
                    numerical=numerical, consistency_checks=numerical_sanity(),
                    raw_fields=dict(nonfinite_count=nonfinite, frames=frames,
                                    min_consecutive_mean_abs_vorticity_change=min(changed),
                                    max_consecutive_mean_abs_vorticity_change=max(changed),
                                    maximum_clipped_fluid_fraction=max(clipped_fraction),
                                    mature_rightward_advection=advection,
                                    caveat="Correlation is a motion diagnostic, not tracked material-particle velocity."),
                    layout_checks="text bounds and text-text overlaps passed at frames 0/360/570/719; probe not clipped",
                    tests=test_summary, inventory=inventory)
    target = output / "verification-manifest.json"
    target.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(dict(status="PASS", manifest=str(target), video_bytes=main.stat().st_size,
                         frame_count=frames, advection=advection,
                         consistency_checks=manifest["consistency_checks"]), indent=2))
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    run(parser.parse_args().root)
