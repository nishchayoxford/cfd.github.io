"""Original, standalone D2Q9 BGK lattice-Boltzmann demonstration.

All coordinates and time steps are in lattice units (dx = dt = 1).
Array layout is [y, x, population]; y increases physically upward.
"""
from __future__ import annotations

import numpy as np
from numba import njit

C = np.array([(0, 0), (1, 0), (0, 1), (-1, 0), (0, -1),
              (1, 1), (-1, 1), (-1, -1), (1, -1)], dtype=np.int64)
W = np.array([4 / 9, 1 / 9, 1 / 9, 1 / 9, 1 / 9,
              1 / 36, 1 / 36, 1 / 36, 1 / 36])
OPPOSITE = np.array([0, 3, 4, 1, 2, 7, 8, 5, 6], dtype=np.int64)


def equilibrium(rho, ux, uy):
    """Second-order isothermal equilibrium, cs^2 = 1/3."""
    cu = ux[..., None] * C[:, 0] + uy[..., None] * C[:, 1]
    speed2 = ux * ux + uy * uy
    return rho[..., None] * W * (1 + 3 * cu + 4.5 * cu * cu
                                 - 1.5 * speed2[..., None])


@njit(cache=True)
def advance(f, solid, tau, inlet_u, steps, open_x=True):
    """Fused pull-stream / BGK collision; stationary link bounce-back.

    f stores post-collision distributions. Transverse boundaries are
    periodic. The optional open-x mode uses a Zou–He velocity inlet and
    first-order zero-gradient incoming populations at the outlet.
    """
    ny, nx, _ = f.shape
    g = np.empty_like(f)
    fi = np.empty(9, dtype=np.float64)
    omega = 1.0 / tau
    for _ in range(steps):
        for y in range(ny):
            for x in range(nx):
                if solid[y, x]:
                    for q in range(9):
                        g[y, x, q] = W[q]
                    continue
                for q in range(9):
                    sx = x - C[q, 0]
                    sy = (y - C[q, 1]) % ny
                    if open_x:
                        if sx < 0:
                            sx = 0  # replaced by velocity reconstruction below
                        elif sx >= nx:
                            sx = nx - 2  # zero-gradient extrapolation
                    else:
                        sx %= nx
                    if solid[sy, sx]:
                        fi[q] = f[y, x, OPPOSITE[q]]
                    else:
                        fi[q] = f[sy, sx, q]
                if open_x and x == 0:
                    rho_in = (fi[0] + fi[2] + fi[4]
                              + 2.0 * (fi[3] + fi[6] + fi[7])) / (1 - inlet_u)
                    fi[1] = fi[3] + (2 / 3) * rho_in * inlet_u
                    fi[5] = fi[7] + 0.5 * (fi[4] - fi[2]) + rho_in * inlet_u / 6
                    fi[8] = fi[6] + 0.5 * (fi[2] - fi[4]) + rho_in * inlet_u / 6
                rho = 0.0
                mx = 0.0
                my = 0.0
                for q in range(9):
                    rho += fi[q]
                    mx += fi[q] * C[q, 0]
                    my += fi[q] * C[q, 1]
                ux = mx / rho
                uy = my / rho
                speed2 = ux * ux + uy * uy
                for q in range(9):
                    cu = C[q, 0] * ux + C[q, 1] * uy
                    eq = W[q] * rho * (1 + 3 * cu + 4.5 * cu * cu - 1.5 * speed2)
                    g[y, x, q] = fi[q] + omega * (eq - fi[q])
        f, g = g, f
    return f


def macroscopic(f, solid):
    """Recover density and velocity; no velocity is assigned inside solids."""
    rho = f.sum(axis=-1)
    ux = (f @ C[:, 0]) / rho
    uy = (f @ C[:, 1]) / rho
    ux[solid] = 0.0
    uy[solid] = 0.0
    return rho, ux, uy


def curl(ux, uy):
    """Signed 2-D vorticity du_y/dx - du_x/dy (positive CCW).

    Second-order centered differences; periodic y and second-order
    one-sided x differences at the inlet/outlet. No spatial filtering.
    """
    return np.gradient(uy, axis=1, edge_order=2) - (
        np.roll(ux, -1, axis=0) - np.roll(ux, 1, axis=0)) * 0.5
