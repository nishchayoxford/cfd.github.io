"""Create a silent, equal-geometric-scale near-wake hero crop.

The source is the encoded computed film, not a second or decorative flow.
The ten-second excerpt is chronological; it is not a seamless-loop claim.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]


def create(source, output, start_frame=360, frames=300):
    source, output = Path(source), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    overlay = Image.new("RGBA", (1920,1080), (0,0,0,0))
    draw = ImageDraw.Draw(overlay)
    title = ImageFont.truetype(str(ROOT / "assets" / "SpaceGrotesk.ttf"), 48)
    title.set_variation_by_axes([600])
    mono = ImageFont.truetype(str(ROOT / "assets" / "JetBrainsMono.ttf"), 23)
    small = ImageFont.truetype(str(ROOT / "assets" / "JetBrainsMono.ttf"), 20)
    draw.text((80,70), "A wake, computed.", font=title, fill=(232,234,240,255), anchor="lt")
    draw.text((1490,84), "Re 120 / D2Q9", font=mono, fill=(174,179,194,255), anchor="lt")
    draw.text((80,138), "U →  /  SIGNED VORTICITY", font=small, fill=(174,179,194,255), anchor="lt")
    draw.rectangle((80,184,158,194), fill=(105,211,211,255))
    draw.text((173,179), "−3", font=small, fill=(105,211,211,255), anchor="lt")
    draw.rectangle((245,184,323,194), fill=(242,163,140,255))
    draw.text((338,179), "+3  /  ωz D/U  /  clipped", font=small, fill=(174,179,194,255), anchor="lt")
    draw.rounded_rectangle((66,955,1854,1027), radius=12, fill=(18,20,27,225))
    draw.text((92,982), "STANDALONE NUMERICAL DEMONSTRATION · NOT VALIDATED RESEARCH", font=small,
              fill=(174,179,194,255), anchor="lt")
    draw.text((1588,980), "PYTHON / CFD", font=mono, fill=(139,149,240,255), anchor="lt")
    overlay_path = output / "hero-overlay.png"
    overlay.save(overlay_path)
    target = output / "flow-hero.mp4"
    filters = "[0:v]crop=1024:576:244:292,scale=1920:1080:flags=lanczos,setsar=1[crop];[crop][1:v]overlay=0:0[out]"
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "warning",
                    "-ss", str(start_frame/30), "-i", str(source), "-i", str(overlay_path),
                    "-filter_complex", filters, "-map", "[out]", "-an", "-r", "30",
                    "-frames:v", str(frames), "-c:v", "libx264", "-preset", "slow",
                    "-crf", "20", "-maxrate", "3600k", "-bufsize", "7200k",
                    "-threads", "4", "-profile:v", "high", "-level:v", "4.1",
                    "-pix_fmt", "yuv420p", "-movflags", "+faststart",
                    "-metadata", "title=Computed cylinder wake | standalone numerical demonstration",
                    "-metadata", "comment=Equal-aspect crop from computed CFD film; not validated research",
                    str(target)], check=True)
    poster_frame = min(150, frames-1)
    poster_path = output / "hero-poster.png"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(target),
                    "-vf", f"select=eq(n\\,{poster_frame})", "-fps_mode", "vfr", "-frames:v", "1",
                    str(poster_path)], check=True)
    Image.open(poster_path).save(output / "hero-poster.webp", quality=95, method=6)
    report = dict(source="flow-film.mp4", source_start_frame=start_frame,
                  source_end_frame=start_frame+frames-1, frames=frames, fps=30,
                  duration_seconds=frames/30, crop=dict(x=244,y=292,width=1024,height=576),
                  output_dimensions=[1920,1080], geometric_aspect_preserved=True,
                  interpretation="Chronological near-wake crop of actual encoded computed field; not a seamless loop",
                  silent=True, poster_frame=poster_frame,
                  scientific_caveat="Standalone numerical demonstration; not validated research")
    (output / "hero.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT / "output" / "flow-film.mp4")
    parser.add_argument("--output", type=Path, default=ROOT / "output")
    args = parser.parse_args()
    print(json.dumps(create(args.source, args.output), indent=2))
