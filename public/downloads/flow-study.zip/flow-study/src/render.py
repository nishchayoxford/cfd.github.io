"""Original, deterministic scientific film composition and H.264 encoding.

Only the computed vorticity field is painted. No procedural vortices,
synthetic flow footage, or template-author imagery are used.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import subprocess
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
BG = (18, 20, 27)
PANEL = (21, 24, 33)
BORDER = (44, 48, 64)
TEXT = (232, 234, 240)
MUTED = (174, 179, 194)
ACCENT = (139, 149, 240)
CYAN = (105, 211, 211)
CORAL = (242, 163, 140)
COLOR_LIMIT = 3.0
FIELD = (96, 292, 1824, 868)


class Composer:
    def __init__(self, cfg, rows):
        self.cfg = cfg
        self.rows = rows
        self.fonts = {}
        self.text_boxes = []
        self.duration = len(rows) / 30
        self.probe = np.array([float(r["probe_uy_over_u"]) for r in rows])

    def font(self, size, mono=False, weight=500):
        key = size, mono, weight
        if key not in self.fonts:
            name = "JetBrainsMono.ttf" if mono else "SpaceGrotesk.ttf"
            font = ImageFont.truetype(str(ROOT / "assets" / name), size)
            font.set_variation_by_axes([weight])
            self.fonts[key] = font
        return self.fonts[key]

    def text(self, draw, xy, text, size, fill=TEXT, mono=False, weight=500):
        font = self.font(size, mono, weight)
        bbox = draw.textbbox(xy, text, font=font, anchor="lt")
        self.text_boxes.append(bbox)
        draw.text(xy, text, font=font, fill=fill, anchor="lt")

    def probe_coordinates(self, index):
        """Fixed ±1 ordinate range; no clipping of measured samples."""
        xx = np.linspace(1322, 1824, len(self.rows))[:index+1]
        yy = 977 - self.probe[:index+1] * 25
        return np.column_stack((xx, yy))

    def colorize(self, values):
        """Fixed, symmetric, piecewise-linear scientific colour mapping."""
        t = np.clip(np.abs(values) / COLOR_LIMIT, 0, 1)
        # No gamma/asinh remapping: colour is linear in signed vorticity.
        palette = np.where((values >= 0)[..., None], np.array(CORAL), np.array(CYAN))
        rgb = np.array(PANEL) + t[..., None] * (palette - np.array(PANEL))
        return np.clip(rgb, 0, 255).astype(np.uint8)

    def frame(self, omega, solid, index):
        self.text_boxes = []
        cfg = self.cfg
        image = Image.new("RGB", (1920, 1080), BG)
        draw = ImageDraw.Draw(image)
        # Editorial header: generous margins, no text on the wake itself.
        draw.line((96, 70, 142, 70), fill=ACCENT, width=3)
        self.text(draw, (158, 60), "COMPUTATIONAL FLUID DYNAMICS", 19, ACCENT, mono=True)
        self.text(draw, (1530, 60), "NUMERICAL STUDY / 01", 18, MUTED, mono=True)
        self.text(draw, (91, 113), "The wake comes alive.", 74, TEXT, weight=600)
        self.text(draw, (97, 213), "A cylinder. A steady inflow. An unsteady wake.", 29, MUTED)
        self.text(draw, (1588, 124), f"Re {cfg['reynolds']:g}", 46, TEXT, weight=500)
        self.text(draw, (1574, 215), "D2Q9 / BGK", 22, ACCENT, mono=True)

        # Equal geometric scale in x and y. Letterbox arbitrary test grids;
        # the production 672x224 grid fills the 1728x576 panel exactly.
        left, top, right, bottom = FIELD
        pw, ph = right - left, bottom - top
        scale = min(pw / cfg["nx"], ph / cfg["ny"])
        fw, fh = round(cfg["nx"] * scale), round(cfg["ny"] * scale)
        fx = left + (pw - fw) // 2
        fy = top + (ph - fh) // 2
        draw.rectangle(FIELD, fill=PANEL)
        # Flip array y once: mathematical y points up, raster y points down.
        scalar = Image.fromarray(np.flipud(omega.astype(np.float32))).resize(
            (fw, fh), Image.Resampling.BILINEAR)
        values = np.asarray(scalar)
        rgb = self.colorize(values)
        # Thin genuine isovorticity contours, not invented streamlines.
        magnitude = np.abs(values)
        band = np.floor(magnitude / 0.5)
        edge = np.zeros(values.shape, dtype=bool)
        edge[:, 1:] |= band[:, 1:] != band[:, :-1]
        edge[1:, :] |= band[1:, :] != band[:-1, :]
        edge &= (magnitude > 0.45) & (magnitude < COLOR_LIMIT)
        rgb[edge] = np.minimum(255, rgb[edge].astype(float) * 1.09 + 5).astype(np.uint8)
        image.paste(Image.fromarray(rgb), (fx, fy))
        draw = ImageDraw.Draw(image)
        draw.rectangle(FIELD, outline=BORDER, width=1)
        # The actual discrete solid mask occludes all field pixels in it.
        mask = Image.fromarray((np.flipud(solid).astype(np.uint8) * 255)).resize(
            (fw, fh), Image.Resampling.NEAREST)
        image.paste((31, 35, 47), (fx, fy, fx + fw, fy + fh), mask)
        # A circular outline identifies nominal geometry; mask remains exact.
        cx = fx + (cfg["cx"] + .5) * scale
        cy = fy + (cfg["ny"] - cfg["cy"] - .5) * scale
        r = cfg["radius"] * scale
        draw.ellipse((cx-r, cy-r, cx+r, cy+r), outline=TEXT, width=2)
        draw.ellipse((cx-3, cy-3, cx+3, cy+3), fill=ACCENT)
        # Sparse context lives in the quiet outer corners of the domain.
        self.text(draw, (124, 322), "U  →", 23, MUTED, mono=True)
        self.text(draw, (1544, 322), f"t* = {float(self.rows[index]['t_star']):05.1f}", 23, TEXT, mono=True)
        bar_length = 4 * 2 * cfg["radius"] * scale
        bx = right - 42 - bar_length
        by = bottom - 38
        draw.line((bx, by, bx + bar_length, by), fill=MUTED, width=2)
        draw.line((bx, by - 5, bx, by + 5), fill=MUTED, width=2)
        draw.line((bx + bar_length, by - 5, bx + bar_length, by + 5), fill=MUTED, width=2)
        self.text(draw, (bx + bar_length / 2 - 15, by - 34), "4D", 19, MUTED, mono=True)
        # Probe corresponds to a single simulated fluid cell downstream.
        probe_x = min(cfg["nx"] - 4, int(cfg["cx"] + 5 * 2 * cfg["radius"]))
        dx = fx + (probe_x + .5) * scale
        dy = cy
        draw.ellipse((dx-4, dy-4, dx+4, dy+4), outline=TEXT, width=1)

        # Scientific key: fixed range, explicit clipping, minimal footer.
        self.text(draw, (96, 906), "SIGNED VORTICITY", 18, MUTED, mono=True)
        self.text(draw, (435, 906), "ωz D / U", 22, TEXT, mono=True)
        legend_values = np.linspace(-COLOR_LIMIT, COLOR_LIMIT, 330)[None, :]
        legend = Image.fromarray(self.colorize(legend_values)).resize((330, 13))
        image.paste(legend, (96, 947))
        self.text(draw, (96, 972), "−3", 19, CYAN, mono=True)
        self.text(draw, (253, 972), "0", 19, MUTED, mono=True)
        self.text(draw, (399, 972), "+3", 19, CORAL, mono=True)
        self.text(draw, (465, 949), "FIXED SCALE", 16, MUTED, mono=True)
        self.text(draw, (465, 978), "CLIPPED AT ±3", 16, MUTED, mono=True)
        self.text(draw, (820, 906), "PHYSICS, NOT A PRESET.", 18, ACCENT, mono=True)
        self.text(draw, (820, 949), "Computed on a 672 × 224 lattice", 22, MUTED)
        self.text(draw, (820, 982), "t* = tU/D  ·  flow left to right", 18, MUTED, mono=True)

        # Numerically sampled cross-stream velocity history, progressively shown.
        self.text(draw, (1322, 906), "WAKE PROBE / uy/U", 18, MUTED, mono=True)
        chart = (1322, 950, 1824, 1004)
        draw.line((chart[0], 977, chart[2], 977), fill=BORDER, width=1)
        if index > 0:
            points = self.probe_coordinates(index)
            xx, yy = points[:, 0], points[:, 1]
            draw.line(list(zip(xx, yy)), fill=ACCENT, width=2)
            draw.ellipse((xx[-1]-3, yy[-1]-3, xx[-1]+3, yy[-1]+3), fill=TEXT)
        draw.line((96, 1028, 1824, 1028), fill=BORDER, width=1)
        self.text(draw, (96, 1044), "STANDALONE NUMERICAL DEMONSTRATION · NOT VALIDATED RESEARCH", 16, MUTED, mono=True)
        self.text(draw, (1570, 1044), "PYTHON / NUMPY / NUMBA", 16, MUTED, mono=True)
        return image


def encode(frames, path, fps=30):
    """Stream RGB frames to a web-compatible, bounded-rate silent MP4."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    command = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "warning",
               "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1920x1080",
               "-framerate", str(fps), "-i", "pipe:0", "-an",
               "-vf", "setsar=1", "-c:v", "libx264", "-preset", "slow",
               "-crf", "20", "-maxrate", "3600k", "-bufsize", "7200k",
               "-threads", "4", "-profile:v", "high", "-level:v", "4.1",
               "-pix_fmt", "yuv420p", "-movflags", "+faststart",
               "-metadata", "title=The wake comes alive | Standalone CFD demonstration",
               "-metadata", "comment=Original computed D2Q9/BGK cylinder wake; not validated research",
               str(path)]
    process = subprocess.Popen(command, stdin=subprocess.PIPE)
    try:
        for frame in frames:
            process.stdin.write(frame.tobytes())
    finally:
        process.stdin.close()
    code = process.wait()
    if code:
        raise RuntimeError(f"ffmpeg failed with status {code}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--output", type=Path, default=ROOT / "output")
    parser.add_argument("--preview", type=int, default=None)
    args = parser.parse_args()
    numerical = json.loads((args.data / "numerical.json").read_text())
    cfg = numerical["config"]
    with (args.data / "diagnostics.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    omega = np.load(args.data / "vorticity.npy", mmap_mode="r")
    solid = np.load(args.data / "solid.npy")
    composer = Composer(cfg, rows)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.preview is not None:
        composer.frame(omega[args.preview], solid, args.preview).save(args.output / f"preview-{args.preview:03d}.png")
        return
    started = time.monotonic()

    def frames():
        for index in range(len(rows)):
            frame = composer.frame(omega[index], solid, index)
            if index % 60 == 0 or index == len(rows) - 1:
                print(f"RENDER {index+1}/{len(rows)} ({time.monotonic()-started:.1f}s)", flush=True)
            if index == 570:
                frame.save(args.output / "flow-poster.png")
                frame.save(args.output / "flow-poster.webp", quality=95, method=6)
            yield frame
    encode(frames(), args.output / "flow-film.mp4")
    (args.output / "render.json").write_text(json.dumps(dict(
        duration_seconds=len(rows)/30, fps=30, expected_frames=len(rows),
        dimensions=[1920,1080], field_limits=[-COLOR_LIMIT, COLOR_LIMIT],
        field_mapping="fixed linear diverging; bilinear spatial display interpolation",
        contours="computed isovorticity at increments of 0.5; none fabricated",
        solid_display="actual raster mask + nominal circle outline",
        geometric_aspect="equal x/y scale; no stretching",
        t_star_range=numerical["t_star_range"], steps_per_frame=cfg["stride"],
        frame_sampling="interval starts: start_step + i*stride; no repeated endpoint",
        poster_source_frame=570, elapsed_seconds=time.monotonic()-started,
        silent=True, status="Standalone numerical demonstration; not validated research"
    ), indent=2) + "\n")


if __name__ == "__main__":
    main()
