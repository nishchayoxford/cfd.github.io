"""Distribution regressions: no dependency on the producer's filesystem."""
from pathlib import Path
import capstone_data

ROOT = Path(__file__).resolve().parent


def test_default_source_is_the_bundled_public_archive():
    assert capstone_data.SOURCE == ROOT / 'evidence-source'
    assert capstone_data.build_payload()['observation_count'] == 104


def test_renderer_uses_the_bundled_production_fonts():
    import generate
    for kind, name in generate.FONTS.items():
        path = Path(name)
        assert path.parent == ROOT / 'assets'
        assert path.is_file()
        assert generate.font(24, kind).getbbox('Capstone F5')[2] > 0


def test_verifier_pins_the_bundled_source_not_a_private_original(tmp_path):
    import shutil
    import verify
    import pytest
    assert hasattr(verify, 'verify_public_source'), 'portable evidence verifier missing'
    result = verify.verify_public_source()
    assert result['unchanged'] is True
    assert result['files_hashed'] == 35
    assert result['scope'] == 'Bundled public evidence subset; not the original complete repository'
    copied = tmp_path / 'evidence-source'
    shutil.copytree(capstone_data.SOURCE, copied)
    victim = copied / 'data/weekly_results/outputs/13.txt'
    victim.write_text(victim.read_text() + '\n')
    with pytest.raises(AssertionError, match='Bundled public evidence changed'):
        verify.verify_public_source(copied)
