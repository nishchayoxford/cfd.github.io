# Capstone evidence brief

## Safe headline
**Learning where to look — black-box optimisation with sparse feedback.**

This is an AI/ML **learning capstone**, described by its public repository as an Imperial College London AI/ML capstone; it is not evidence of a degree, professional deployment or industrial validation.[7]

## What is verified

All repository-relative source anchors below resolve inside `evidence-source/` in this download. It is a selected public subset, not a full repository checkout.

| Claim | Evidence and exact public source anchors |
|---|---|
| Eight independent maximisation objectives, 13 returned observations each; 104 observations total. Dimensions F1–F8 are 2, 2, 3, 4, 4, 5, 6, 8. | `data/weekly_results/inputs/13.txt:L1–L21`, `outputs/13.txt:L1–L13`. All 26 weekly input/output files were parsed without executing their text, and each earlier file equals the corresponding prefix of the final archive.[5][6] |
| W5 uses Ridge on F2, F5, F7. It fits a linear surrogate, chooses the observed incumbent and moves along the normalized coefficient direction. | `scripts/capstoneweek5.py:L144–L160`, `L192–L240`; the DATA mapping names F2/F5/F7, `L74–L125`.[1] |
| W7 uses Matérn GP + Expected Improvement on F5/F7. Its candidate pool combines local Gaussian samples with uniform global samples. | `scripts/capstoneweek7.py:L401–L441`, `L444–L510`. Despite a “trust-region” function name, this version does **not** hard-restrict every candidate to a local box.[2] |
| W8 changes F5/F7 to local-only GP+EI with per-coordinate hard bounds. | `scripts/capstoneweek8.py:L487–L527`, `L549–L555`. F5 uses seed 105, 50,000 initial candidates, sigma 0.006 and radius multiplier 3; radius is 0.018.[3] |
| W13 implements GP + Gradient Boosting, a leave-one-out parameter grid, UCB/EI hybrid scoring and function-specific local/global candidates. | `scripts/capstoneweek13.py:L125–L198`, `L236–L398`, `L523–L641`, `L644–L723`. UCB uses the ensemble mean plus GP standard deviation; EI uses the GP mean/standard deviation; disagreement is penalized. F1 is a separate incumbent-nearby heuristic (`L407–L414`), not an ensemble fit.[4] |
| W13 returned values improve over W12 on F1, F3, F4, F5, F6, F7. Five new observed bests: F1, F4, F5, F6, F7. F2/F8 decline. | Direct numerical comparison of `outputs/13.txt:L12–L13` and all previous rows.[6] |
| F5 moves from 287.4343816627659 (W1) to 910.4815138254987 (W13); W13 is 35.38633814253998% above W12, and 3.1676151911907557 times W1. | `outputs/13.txt:L1`, `L12–L13`. These are ratios of positive F5 returns only, not aggregate performance or proximity to a known optimum.[6] |
| F5's W7 setback is real: W6 365.66328225833024 → W7 283.75880106841055 → W8 413.12789189378645. | `outputs/13.txt:L6–L8`; W8's archived four-dimensional query is exactly present after six-decimal rounding in the regenerated, filtered candidate pool.[3][5][6] |

## Audit findings that should not be copied uncritically

- **Weekly-summary counts contain errors.** Direct data comparisons give W9 **6** improvements, W11 **5**, W12 **7** (not the summary's 5, 6, 6). The final W13 count of six is correct. This brief and the film use the archive, not the prose summary.[6]
- **A full W13 script replay was actually executed**, not just inspected. It exited successfully and reproduced F1–F7's submitted six-decimal input vectors exactly. **F8 did not match** the archived W13 vector. The replay's F8 is `0.102233-0.231957-0.348308-0.504177-0.621585-0.741103-0.857885-0.958103`; the archived vector is `0.106469-0.267786-0.293412-0.469094-0.615386-0.691452-0.916304-0.908584`.[5] The reason is unresolved; unpinned upstream dependencies are a reproducibility limitation, not a proven explanation. `evidence/week13-replay.txt` retains the public numerical output of that execution (no machine paths or environment logs).
- The audit does not rerun a hidden objective service or independently authenticate portal returns. It verifies the public archive's internal consistency and uses those archived returns.[5][6]
- The available weekly implementation files begin at W5. W1–W4 “random/manual exploration” is a README description, not an audited code implementation.[7]
- “Trust-region-style” is supported. Calling this a complete implementation of the published TuRBO algorithm is not justified by these local-search scripts.[3][4]
- Improvement under thirteen observations does not establish a global optimum, calibrated uncertainty, robust out-of-sample accuracy or superiority to a benchmark.[5][6]

## Visual/data contract

1. The opening shows actual F5 observations, projected onto x1/x2 with height equal to returned score. F5 is **four-dimensional**; the projection is explicitly labelled.
2. The surface is a **new retrospective GP mean slice**, fitted in all four dimensions to the thirteen actual F5 returns. It uses a fixed isotropic Matérn 5/2 kernel (length scale 0.12), `alpha=1e-6`, `normalize_y=True`, no kernel optimisation, no posterior variance shading. x3=0.899183 and x4=0.849258 are fixed at W13's input. This is not the true objective, not the historical ensemble, and not a predictive-accuracy claim. The highlighted dot identifies the W13 input on this mean slice. Mesh height/color are computed model means; soft illumination is decorative shading, not uncertainty.
3. The W8 cloud regenerates the archived candidate-generation algorithm: **49,482** candidates survive the four-dimensional bounds and duplicate-distance filter. Every 29th retained candidate is shown. Its square is the x1/x2 projection of the real per-coordinate bound. No GP scoring or posterior is implied by that scene. The archived W8 query matches a generated candidate after portal rounding.
4. F1–F8 curves are best-so-far maximisation staircases, normalized **separately per function** by `(incumbent_t − min(all 13 returns)) / (max(all 13 returns) − min(all 13 returns))`. All final incumbents therefore equal 1 by construction. This is neither percent-of-optimum nor a cross-function ranking. Do not average these normalized curves into an “overall improvement” score. F1 has an extremely small signal.
5. F5's large chart shows raw returned scores and the cumulative maximum separately, including the W7 decline. Connecting line segments guide the eye; the actual evaluations are discrete dots. There are no fabricated intermediate measurements.
6. Only the bundled public capstone observations and scripts underpin this film. The package contains no hidden objective implementation and makes no deployment or degree claim.

## Website-ready copy

**Title:** Learning where to look  
**Type:** AI/ML learning capstone · Black-box optimisation

> Eight unknown objective functions. Thirteen rounds of feedback. I developed a Python optimisation workflow that progressed from Ridge surrogates to Gaussian-process search, local trust-region constraints and a final GP/gradient-boosting ensemble. The project records both the failed jumps and the recoveries: F5's observed score rose from 287.43 to 910.48, while F2 and F8 declined in the final round. These are learning-capstone results, not industrial deployment or global-optimality claims.[1][2][4]

**Concise card:** A small-data optimisation study in Python: surrogate modelling, Bayesian acquisition functions and controlled local search, evaluated against thirteen rounds of archived feedback.[1][2][3]

**Supported skills:** Python; NumPy; scikit-learn; Ridge regression; Gaussian-process regression; Gradient Boosting regression; Expected Improvement; UCB-style acquisition; constrained candidate generation; leave-one-out cross-validation; practical hyperparameter selection; reproducible numerical analysis; experiment documentation and failure analysis.[1][2][4]

**Not supported by this repository:** deep-learning training, LLM fine-tuning, reinforcement learning, production MLOps, industrial CFD validation, a degree award, or certified benchmark-leading performance.

## Generated files for integration (not bundled)

- `optimisation-showcase.mp4`: silent 30-second film with readable holds. Use `muted playsinline preload="metadata"` and a poster. Respect reduced-motion preferences; this is a complete story, not a seamless loop.
- `optimisation-poster.webp` / `.png`: matching full-HD poster. WebP is the lighter web asset.
- `capstone-chart-data.json`: complete raw inputs/returns, per-function incumbents, normalized incumbents, dimensions, best weeks, verified final-round counts and normalization caveats. Choose raw F5 for a small interactive chart; provide a textual data-table alternative.
- `encoded-contact-sheet.jpg`: decoded beginning/middle/end frames, not source-render proxies.
- `verification-manifest.json`: numerical assertions, actual ffprobe output, hashes of the bundled public source subset and replay mismatch disclosure. It does not claim immutability of an unavailable original repository.

## Sources

[1] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/scripts/capstoneweek5.py
[2] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/scripts/capstoneweek7.py
[3] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/scripts/capstoneweek8.py
[4] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/scripts/capstoneweek13.py
[5] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/data/weekly_results/inputs/13.txt
[6] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/data/weekly_results/outputs/13.txt
[7] https://github.com/nishchayoxford/bbo-capstone-imperial/blob/main/README.md
