"""Read-only extraction of public capstone data; never evaluates archive text."""
from pathlib import Path
import ast
import numpy as np

SOURCE = Path(__file__).resolve().parent / 'evidence-source'


def parse_archive(text):
    """Parse lists printed as array()/np.float64() with a strict AST allowlist."""
    def walk(n):
        if isinstance(n, ast.Constant) and type(n.value) in (float, int):
            return n.value
        if isinstance(n, (ast.List, ast.Tuple)):
            return [walk(x) for x in n.elts]
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            x = walk(n.operand)
            if not isinstance(x, (int, float)):
                raise ValueError('non-numeric operand')
            return -x if isinstance(n.op, ast.USub) else x
        if isinstance(n, ast.Call) and len(n.args) == 1 and not n.keywords:
            array = isinstance(n.func, ast.Name) and n.func.id == 'array'
            scalar = (isinstance(n.func, ast.Attribute) and n.func.attr == 'float64'
                      and isinstance(n.func.value, ast.Name) and n.func.value.id == 'np')
            if array or scalar:
                return walk(n.args[0])
        raise ValueError(f'Forbidden archive syntax: {type(n).__name__}')
    tree = ast.parse(text)
    if any(not isinstance(n, ast.Expr) for n in tree.body):
        raise ValueError('Only literal records permitted')
    return [walk(n.value) for n in tree.body]


def progress(values):
    """Maximisation incumbent; min/max scale uses all observed returns, not an optimum."""
    y = np.asarray(values, dtype=float)
    if y.ndim != 1 or y.size == 0 or not np.isfinite(y).all():
        raise ValueError('Expected a non-empty finite response vector')
    b = np.maximum.accumulate(y)
    lo, hi = float(y.min()), float(y.max())
    n = np.zeros_like(b) if hi == lo else (b - lo) / (hi - lo)
    return {'observed': y.tolist(), 'best_so_far': b.tolist(),
            'normalized_best_so_far': n.tolist(), 'observed_min': lo,
            'observed_max': hi, 'best_week': int(np.argmax(y)) + 1,
            'final_observed': float(y[-1]), 'final_best': float(b[-1])}


def build_payload(source=SOURCE):
    """One public-safe data contract for charts, film, and verification."""
    source = Path(source)
    x = parse_archive((source/'data/weekly_results/inputs/13.txt').read_text())
    y = np.array(parse_archive((source/'data/weekly_results/outputs/13.txt').read_text()), float)
    if len(x) != 13 or y.shape != (13, 8) or not np.isfinite(y).all():
        raise ValueError('Expected 13 rounds × 8 functions')
    dims = [2, 2, 3, 4, 4, 5, 6, 8]
    functions = []
    for j, dim in enumerate(dims):
        xx = np.array([r[j] for r in x], float)
        if xx.shape != (13, dim) or not np.isfinite(xx).all() or not ((xx >= 0) & (xx <= .999999)).all():
            raise ValueError(f'Invalid F{j+1} inputs')
        f = {'id': f'F{j+1}', 'dimensions': dim, 'inputs': xx.tolist(), **progress(y[:, j])}
        f['w13_vs_w12_delta'] = float(y[-1,j] - y[-2,j])
        # Ratios/percent change are published only for positive, well-scaled F5.
        if j == 4:
            f['w13_vs_w12_percent'] = float(100 * (y[-1,j] / y[-2,j] - 1))
            f['w13_vs_w1_ratio'] = float(y[-1,j] / y[0,j])
        functions.append(f)
    prefixes = []
    for k in range(1, 14):
        xk = parse_archive((source/f'data/weekly_results/inputs/{k}.txt').read_text())
        yk = np.array(parse_archive((source/f'data/weekly_results/outputs/{k}.txt').read_text()))
        ok = xk == x[:k] and np.array_equal(yk, y[:k])
        prefixes.append(ok)
        if not ok:
            raise ValueError(f'Cumulative archive disagreement at week {k}')
    names = [f['id'] for f in functions]
    return {
        'schema_version': 1, 'title': 'Learning where to look',
        'classification': 'AI/ML learning capstone — not an industrial deployment or degree claim',
        'source_repository': 'https://github.com/nishchayoxford/bbo-capstone-imperial',
        'source_files': ['data/weekly_results/inputs/13.txt', 'data/weekly_results/outputs/13.txt'],
        'objective': 'maximise returned score independently for each function',
        'rounds': 13, 'observation_count': int(y.size), 'weeks': list(range(1,14)),
        'normalization': {
            'formula': '(max(y[1:t]) - min(y[1:13])) / (max(y[1:13]) - min(y[1:13]))',
            'scope': 'independent per function, retrospective observed range',
            'constant_series': 'zero',
            'warning': 'All final incumbents equal 1 by construction. Not percent of optimum, not a cross-function performance ranking. F1 scores are near zero.'},
        'functions': functions,
        'improvement_counts': np.sum(np.diff(y,axis=0) > 0,axis=1).tolist(),
        'final_round': {
            'improved': [names[j] for j in range(8) if y[-1,j] > y[-2,j]],
            'declined': [names[j] for j in range(8) if y[-1,j] < y[-2,j]],
            'new_bests': [names[j] for j in range(8) if y[-1,j] > np.max(y[:-1,j])]},
        'all_cumulative_prefixes_exact': all(prefixes),
        'limitations': ['13 observations per objective; no global-optimality or held-out generalisation claim.',
                        'No combined objective or objective-rank comparison.',
                        'Rendered surrogate is a new retrospective fit, not the unknown objective.']}


def surrogate_slice(x, y, side=65):
    """Fit in every input dimension; vary the first two only in the render plane.

    This is a new visualization model, deliberately NOT a replay of W13's
    GP/GBR ensemble. Kernel length scale is fixed, not cosmetically optimized.
    No posterior variance or accuracy metric is displayed.
    """
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import Matern
    x, y = np.asarray(x,float), np.asarray(y,float)
    if x.ndim != 2 or x.shape[0] != len(y) or x.shape[1] < 2:
        raise ValueError('Need aligned observations with at least two coordinates')
    anchor = x[int(np.argmax(y))]
    span = np.maximum(np.ptp(x[:,:2],axis=0), .05)
    low = np.maximum(0., x[:,:2].min(axis=0) - .18*span)
    high = np.minimum(.999999, x[:,:2].max(axis=0) + .18*span)
    u,v = np.meshgrid(np.linspace(low[0],high[0],side), np.linspace(low[1],high[1],side))
    q = np.tile(anchor,(side*side,1)); q[:,0]=u.ravel(); q[:,1]=v.ravel()
    model = GaussianProcessRegressor(kernel=Matern(length_scale=.12, nu=2.5),
                                     alpha=1e-6, optimizer=None, normalize_y=True)
    model.fit(x,y)
    z = model.predict(q).reshape(side,side)
    return {'u':u, 'v':v, 'mean':z, 'queries':q, 'model':model,
            'metadata':{'kind':'retrospective GP mean slice; not objective or uncertainty',
                        'function_dimensions':int(x.shape[1]),'training_observations':len(y),
                        'varying_coordinates':[1,2], 'fixed_coordinates':anchor[2:].tolist(),
                        'slice_bounds':[low.tolist(),high.tolist()],
                        'kernel':str(model.kernel_), 'alpha':1e-6,'normalize_y':True,
                        'predicted_range':[float(z.min()),float(z.max())],
                        'historical_policy_replay':False}}


def week8_pool(x, y):
    """Regenerate F5 W8 candidate geometry, not GP scoring; source week8.py 495–519,549–552."""
    x, y = np.asarray(x,float), np.asarray(y,float)
    center = x[int(np.argmax(y))]
    pool = np.clip(center + np.random.default_rng(105).normal(0,.006,(50000,x.shape[1])),0,.999999)
    pool = pool[(np.abs(pool-center) <= .018).all(axis=1)]
    nearest = np.linalg.norm(pool[:,None,:]-x[None,:,:],axis=2).min(axis=1)
    return pool[nearest > 1e-6]
