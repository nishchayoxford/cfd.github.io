from pathlib import Path
import importlib
import numpy as np
import pytest


def module():
    assert Path(__file__).with_name('capstone_data.py').exists(), 'safe data parser not implemented'
    return importlib.import_module('capstone_data')


def test_parse_numpy_printed_data_without_execution():
    m = module()
    assert m.parse_archive('[array([0.2, 0.3]), array([0.4])]\n[array([0.5,\n0.6]), array([0.7])]') == [[[0.2, 0.3], [0.4]], [[0.5, 0.6], [0.7]]]
    assert m.parse_archive('[np.float64(-1.2e-7), np.float64(9.0)]') == [[-1.2e-7, 9.0]]
    with pytest.raises(ValueError):
        m.parse_archive("__import__('os').system('false')")


def test_progress_is_observed_incumbent_not_percentage_of_optimum():
    m = module()
    assert hasattr(m, 'progress'), 'incumbent transform not implemented'
    p = m.progress([2.0, 1.0, 3.0, 2.5, 5.0])
    np.testing.assert_array_equal(p['best_so_far'], [2, 2, 3, 3, 5])
    np.testing.assert_allclose(p['normalized_best_so_far'], [.25, .25, .5, .5, 1.])
    assert p['best_week'] == 5
    assert p['final_observed'] == 5
    assert m.progress([2., 2.])['normalized_best_so_far'] == [0., 0.]
    tiny = m.progress([1e-100, 3e-100, 2e-100])
    assert tiny['normalized_best_so_far'] == [0., 1., 1.]
    with pytest.raises(ValueError):
        m.progress([1., float('nan')])


def test_real_archive_contract_and_truthful_claims():
    m = module()
    assert hasattr(m, 'build_payload'), 'archive-to-chart contract not implemented'
    p = m.build_payload(m.SOURCE)
    assert p['rounds'] == 13 and p['observation_count'] == 104
    assert [f['dimensions'] for f in p['functions']] == [2, 2, 3, 4, 4, 5, 6, 8]
    assert [f['best_week'] for f in p['functions']] == [13, 8, 10, 13, 13, 13, 13, 12]
    assert p['final_round']['improved'] == ['F1','F3','F4','F5','F6','F7']
    assert p['final_round']['new_bests'] == ['F1','F4','F5','F6','F7']
    assert p['improvement_counts'][-3:] == [5,7,6]
    f = p['functions'][4]
    assert f['observed'][6] == 283.75880106841055
    assert f['final_best'] == 910.4815138254987
    assert f['best_so_far'][6] == f['observed'][5]
    assert f['w13_vs_w12_percent'] == pytest.approx(35.38633814253998)
    for f in p['functions']:
        assert len(f['observed']) == len(f['inputs']) == len(f['best_so_far']) == 13
        assert all(len(v) == f['dimensions'] for v in f['inputs'])
        assert np.min(np.diff(f['best_so_far'])) >= 0


def test_surrogate_slice_fixes_hidden_coordinates():
    m = module()
    assert hasattr(m, 'surrogate_slice'), 'retrospective slice not implemented'
    x = np.array([[0.,0.,.2,.7],[1.,0.,.4,.6],[0.,1.,.3,.8],[1.,1.,.5,.9]])
    y = np.array([2.,4.,3.,5.])
    result = m.surrogate_slice(x, y, side=9)
    assert result['mean'].shape == (9,9)
    assert result['queries'].shape == (81,4)
    np.testing.assert_array_equal(result['queries'][:,2:], np.tile(x[3,2:],(81,1)))
    assert np.isfinite(result['mean']).all()
    np.testing.assert_allclose(result['model'].predict(result['queries']).reshape(9,9), result['mean'])
    assert result['metadata']['kind'] == 'retrospective GP mean slice; not objective or uncertainty'


def test_week8_candidate_geometry_matches_archived_returned_query():
    m = module()
    assert hasattr(m, 'week8_pool'), 'archived local search geometry not implemented'
    p = m.build_payload(); x = np.array(p['functions'][4]['inputs'])
    pool = m.week8_pool(x[:7], p['functions'][4]['observed'][:7])
    assert len(pool) > 45000
    assert np.max(np.abs(pool-x[5])) <= .018
    assert np.min(np.linalg.norm(np.round(pool,6)-x[7],axis=1)) == 0.
    assert np.max(np.abs(x[6]-x[5])) > .018
