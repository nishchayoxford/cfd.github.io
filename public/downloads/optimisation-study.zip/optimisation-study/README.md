# Learning where to look — portable reproduction

**Public AI/ML learning capstone, not industrial deployment, a degree claim or a known-optimum benchmark.** This is the source package for the silent 30-second, 1920×1080, 30 fps optimisation film. It contains the actual generators, all eight original tests plus three portability regressions, pinned dependencies, unmodified production fonts with licenses, and the relevant public archive. Finished films, posters, environments, caches and machine-local execution logs are deliberately omitted.

## Requirements and full reproduction

Python **3.12**, `uv` (or Python's `venv`/`pip`), and `ffmpeg`/`ffprobe` with `libx264` on PATH. The reference system used Python 3.12.3 and FFmpeg 6.1.1. Python packages are fully pinned in `requirements.lock.txt`; system libraries and FFmpeg are not pinned. Linux was exercised. Relative paths also support macOS with these dependencies, but macOS was not tested. Bundled Inter and Hack fonts eliminate system-font path assumptions. No network is used after dependency installation; no hidden objective service is called.

```sh
unzip optimisation-study.zip
cd optimisation-study
uv venv --python 3.12 .venv
uv pip sync --python .venv/bin/python requirements.lock.txt
mkdir -p .scratch
export TMPDIR="$PWD/.scratch"
export PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=1
.venv/bin/python -m pytest test_data.py test_render.py test_verify.py test_portability.py -q -p no:cacheprovider --basetemp=.test-tmp
.venv/bin/python generate.py --all
.venv/bin/python verify.py
ffmpeg -v error -i optimisation-showcase.mp4 -f null -
```

Without `uv`, replace its two setup commands with `python3.12 -m venv .venv` and `.venv/bin/python -m pip install -r requirements.lock.txt`. Do not use Python `-O`: verification uses assertions.

`generate.py` defaults to the bundled **`evidence-source/`**, resolved relative to its own file, not a developer's original folder. Full reproduction writes to the extracted package root. `verify.py` checks that default output location, the 900-frame/30-second media contract, returned-data equality, all 26 cumulative archive prefixes, the recomputed GP grid, W8 candidate membership and hashes of the **35-file bundled public subset**. It does **not** require or claim verification of an unavailable complete original repository. A matching hash is an integrity check, not independent authentication of portal observations.

For a quick practical preview without the full film:

```sh
.venv/bin/python generate.py --preview --output preview-check
```

This produces real chapter frames, both poster formats, chart data and the fitted surrogate grid from all bundled returns. The full verifier is for the full default-root reproduction above, not the separate preview directory. FFmpeg output/metadata bytes can vary between platforms even with identical source data; the tests and numerical contracts remain the acceptance criteria.

## Historical query replay — mismatch retained

`evidence/week13-replay.txt` is the original public numerical execution transcript. It contains no machine path or environment log. It reproduced the W13 archived queries for **F1–F7**, but **F8 differs and the reason remains unresolved**:

- Replayed F8: `0.102233-0.231957-0.348308-0.504177-0.621585-0.741103-0.857885-0.958103`
- Archived F8: `0.106469-0.267786-0.293412-0.469094-0.615386-0.691452-0.916304-0.908584`

`verify.py` compares that transcript against the archived inputs and publishes both matches and mismatches; a successful technical verification is **not** an all-functions-replay success claim. To run the complete historical query generator again (more expensive than rendering the preview), from this directory:

```sh
OPENBLAS_NUM_THREADS=1 .venv/bin/python evidence-source/scripts/capstoneweek13.py > week13-replay-new.txt
.venv/bin/python -c 'import json; from pathlib import Path; from capstone_data import build_payload; from verify import compare_replay; p=build_payload(); expected={f["id"]:"-".join(format(v,".6f") for v in f["inputs"][-1]) for f in p["functions"]}; print(json.dumps(compare_replay(Path("week13-replay-new.txt").read_text(),expected),indent=2))'
```

This is **query generation only**. No returned score is re-evaluated. Upstream dependencies were not historically pinned; this is a limitation, not a proven explanation of the F8 discrepancy. The retrospective film surface is a separate display model, not this historical policy.

## Method and limits

- Eight independent maximisation functions, thirteen archived returns each: **104 observations**, dimensions **2, 2, 3, 4, 4, 5, 6, 8**. Parsing uses a strict AST allowlist rather than executing data files.
- Historical methods: W5 Ridge; W7 local/global GP + Expected Improvement; W8 locally bounded candidates; W13 GP/Gradient Boosting ensemble with leave-one-out tuning and hybrid UCB/EI scoring. F1 has its own heuristic. These scripts are trust-region-style search, not a claimed full TuRBO implementation.
- The F5 surface is a **new retrospective four-dimensional GP mean slice** fitted to thirteen returns, isotropic Matérn 5/2 with fixed length scale 0.12, alpha 1e-6, normalized targets and no kernel optimisation. Only x1/x2 vary; x3=0.899183 and x4=0.849258 are fixed. It is not the unknown objective, the historical ensemble, uncertainty, or demonstrated predictive accuracy.
- W8's cloud is the actual candidate-generation geometry: 49,482 surviving four-dimensional candidates, local per-coordinate radius 0.018. The view shows a projection/subsample, not GP scoring. The archived query is present after six-decimal rounding.
- Best-so-far curves are maximisation incumbents, normalized **separately** by each function's full observed range. All final normalized incumbents equal one by construction: **not percent of optimum and not a cross-function ranking**. No aggregate performance statistic is justified.
- F5's W7 setback and final-round F2/F8 declines remain visible. W13 improves six returned scores but creates only five new observed bests. Tiny F1 values are not treated as numerical zero.
- No hidden objective, independent portal authentication, held-out validation, global-optimality proof, industrial benchmark or calibrated uncertainty claim. Thirteen observations are a small-data learning exercise.
- Original `results/weekly_summary.md` has wrong W9/W11/W12 improvement counts. The data yield **6/5/7**. It is retained unmodified as historical evidence; see `EVIDENCE.md`, not that prose, for audited claims.

## Contents and provenance

- `capstone_data.py`, `generate.py`, `verify.py`: numerical parser/model, original film composition and portable verification.
- `test_data.py`, `test_render.py`, `test_verify.py`, `test_portability.py`: scientific/visual contracts and distribution regressions.
- `evidence-source/`: byte-identical subset of the public repository: 26 cumulative data files, W5/W7/W8/W13 scripts, README, model card, weekly summary, historical requirements and MIT license. Its upstream README describes files outside this selected subset; those references are not extra dependencies for these commands.
- `evidence-source.sha256.json`: exact 35-file public source inventory. Use the **root** lockfile for reproduction, not the historical unpinned requirements under `evidence-source/`.
- `evidence/`: original chart payload, surrogate metadata and W13 numerical replay transcript for comparison.
- `EVIDENCE.md` and `citations.json`: public URLs, line anchors, supported claims and adverse evidence.
- `assets/`: unchanged production Inter Display/Inter and Hack fonts. Inter notices and full Apache 2.0 text are included; Hack is MIT/Bitstream Vera. Font notices govern the fonts separately from `LICENSE` (MIT code/composition and public-source MIT notice).
- `MANIFEST.sha256.json`: hashes/byte counts of every other distributed file.

Public source: <https://github.com/nishchayoxford/bbo-capstone-imperial>. No original local checkout is needed. Only package path defaults, font lookup, public verification scope and distribution documentation were adapted; archive data, historical scripts, model settings and film composition were not changed.
