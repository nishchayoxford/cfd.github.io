#!/usr/bin/env python3
"""Cinematic public-capstone film, rendered from verified returned observations.

Run: OPENBLAS_NUM_THREADS=1 .venv/bin/python generate.py --all
Pillow renders composed frames; NumPy projects a real 4D GP-mean slice.
This retrospective display model is NOT the historical ensemble or objective.
All paths written by this script are under --output (defaults to this file's dir).
"""
from pathlib import Path
import argparse
import functools
import json
import math
import subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from capstone_data import SOURCE, build_payload, surrogate_slice, week8_pool

W, H, FPS, DURATION = 1920, 1080, 30, 30
ROOT = Path(__file__).resolve().parent
BG = (18,20,27)
RAISED = (26,29,38)
INK = (232,234,240)
BODY = (174,179,194)
VIOLET = (139,149,240)
CYAN = (119,220,218)
MUTED = (98,108,133)
CORAL = (224,160,142)
GRID = (48,53,70)
FONTS = {
    'display': str(ROOT / 'assets/InterDisplay-Medium.otf'),
    'bold': str(ROOT / 'assets/InterDisplay-SemiBold.otf'),
    'body': str(ROOT / 'assets/Inter-Regular.otf'),
    'mono': str(ROOT / 'assets/Hack-Regular.ttf'),
}


def ease(v):
    v = float(np.clip(v,0.,1.))
    return v*v*(3.-2.*v)


def mix(a,b,t):
    return tuple(int(x*(1-t)+y*t) for x,y in zip(a,b))


@functools.lru_cache(maxsize=80)
def font(size,kind='body'):
    return ImageFont.truetype(FONTS[kind], int(size))


class Renderer:
    def __init__(self, source=SOURCE):
        self.payload = build_payload(source)
        self.f5 = self.payload['functions'][4]
        self.x = np.array(self.f5['inputs'])
        self.y = np.array(self.f5['observed'])
        self.slice = surrogate_slice(self.x,self.y,side=65)
        self.pool = week8_pool(self.x[:7],self.y[:7])
        self.layout_violations = []
        self.boxes = []
        # Deterministic, soft ambient light; no fake data or random stars.
        yy,xx = np.mgrid[0:H,0:W]
        light = np.exp(-((xx-1390)/770)**2-((yy-545)/535)**2)
        light2 = np.exp(-((xx-1080)/800)**2-((yy-1030)/280)**2)
        arr=np.empty((H,W,3),np.uint8)
        for k in range(3):
            arr[:,:,k] = np.clip(BG[k]+light*[8,10,21][k]+light2*[0,3,5][k],0,255)
        self.background = Image.fromarray(arr)
        u,v,z = self.slice['u'],self.slice['v'],self.slice['mean']
        self.uv = np.stack([(u-u.min())/np.ptp(u)*2-1,(v-v.min())/np.ptp(v)*2-1],axis=-1)
        self.zz = (z-250)/750
        faces=[]
        colors=[]
        # Physically motivated directional lighting on the displayed surface.
        du,dv=np.gradient(self.zz,2/(len(z)-1),2/(len(z)-1))
        for j in range(len(z)-1):
            for i in range(len(z)-1):
                faces.append(((j,i),(j,i+1),(j+1,i+1),(j+1,i)))
                value=float((z[j,i]-z.min())/np.ptp(z))
                c=mix((47,55,96),VIOLET,ease(value*1.4)) if value<.66 else mix(VIOLET,CYAN,(value-.66)/.34)
                norm=np.array([-dv[j,i],-du[j,i],1.0]); norm/=np.linalg.norm(norm)
                lamp=np.array([-.35,-.55,.8]); lamp/=np.linalg.norm(lamp)
                shade=.68+.32*max(0,float(norm@lamp))
                colors.append(tuple(int(k*shade) for k in c))
        self.faces=faces; self.face_colors=colors

    def text(self,d,xy,string,size=26,color=INK,kind='body',anchor='lt'):
        f=font(size,kind)
        box=d.textbbox(xy,string,font=f,anchor=anchor)
        if box[0]<38 or box[1]<35 or box[2]>W-38 or box[3]>H-28:
            self.layout_violations.append({'text':string,'box':list(box)})
        self.boxes.append((string,box))
        d.text(xy,string,font=f,fill=color,anchor=anchor)

    def common(self,im,chapter,t):
        d=ImageDraw.Draw(im)
        self.text(d,(88,62),'N /  SCIENTIFIC COMPUTING',21,BODY,'mono')
        self.text(d,(1832,62),'AI/ML LEARNING CAPSTONE',21,BODY,'mono',anchor='rt')
        d.line((88,108,1832,108),fill=GRID,width=1)
        labels=['OBSERVE','MODEL','CONTROL','MEASURE']
        for i,label in enumerate(labels):
            x=88+i*262
            col=VIOLET if i==chapter else MUTED
            self.text(d,(x,989),f'0{i+1}  {label}',19,col,'mono')
            d.line((x,1026,x+208,1026),fill=GRID,width=2)
            if i==chapter:
                d.line((x,1026,x+208,1026),fill=col,width=3)
        self.text(d,(1832,993),'PUBLIC DATA / 13 ROUNDS / 8 FUNCTIONS',18,BODY,'mono',anchor='rt')
        return im

    def project(self,xy,z,theta=-.58,center=(1325,746),scale=352,zscale=360):
        xy=np.asarray(xy); z=np.asarray(z)
        c,s=np.cos(theta),np.sin(theta)
        rx=xy[...,0]*c-xy[...,1]*s
        ry=xy[...,0]*s+xy[...,1]*c
        return np.stack([center[0]+rx*scale,center[1]+ry*scale*.46-z*zscale],axis=-1)

    def grid3d(self,d,theta,center=(1325,746),scale=352,zscale=360):
        for n in np.linspace(-1,1,11):
            for xy in [np.array([[-1,n],[1,n]]),np.array([[n,-1],[n,1]])]:
                p=self.project(xy,0,theta,center,scale,zscale)
                d.line([tuple(x) for x in p],fill=GRID,width=1)
        corners=np.array([[-1,-1],[1,-1],[1,1],[-1,1],[-1,-1]])
        p=self.project(corners,0,theta,center,scale,zscale)
        d.line([tuple(x) for x in p],fill=(72,80,110),width=2)

    def surface(self,im,q,poster=False):
        d=ImageDraw.Draw(im)
        theta=-.66+.16*ease(q/7.)
        center=(1336,745 if not poster else 730)
        scale=351
        self.grid3d(d,theta,center,scale)
        pts=self.project(self.uv,self.zz,theta,center,scale)
        # Painter order follows camera depth. All heights are the fitted means.
        depths=self.uv[...,0]*math.sin(theta)+self.uv[...,1]*math.cos(theta)
        order=sorted(range(len(self.faces)),key=lambda k:np.mean([depths[j,i] for j,i in self.faces[k]]))
        for k in order:
            d.polygon([tuple(pts[j,i]) for j,i in self.faces[k]],fill=self.face_colors[k])
        # Delicate isoparametric lines reveal geometry, not posterior uncertainty.
        for j in range(0,len(pts),4):
            d.line([tuple(p) for p in pts[j]],fill=(127,151,205),width=1)
        for i in range(0,len(pts),4):
            d.line([tuple(p) for p in pts[:,i]],fill=(109,130,178),width=1)
        # Incumbent is the only measured point exactly on the fixed-coordinate slice.
        lo=np.array(self.slice['metadata']['slice_bounds'][0]); hi=np.array(self.slice['metadata']['slice_bounds'][1])
        xy=(self.x[-1,:2]-lo)/(hi-lo)*2-1
        z=(self.slice['model'].predict(self.x[-1:])[0]-250)/750
        p=self.project(xy,z,theta,center,scale)
        x,y=map(float,p)
        d.ellipse((x-7,y-7,x+7,y+7),fill=INK)
        d.ellipse((x-14,y-14,x+14,y+14),outline=CYAN,width=2)
        # Recessed numeric scale, with predicted rather than observed quantities.
        self.text(d,(915,890),'x1',22,BODY,'mono')
        self.text(d,(1760,827),'x2',22,BODY,'mono')
        self.text(d,(1803,228),'GP MEAN',20,CYAN,'mono',anchor='rt')
        low,high=self.slice['metadata']['predicted_range']
        for k in range(220):
            v=k/219
            col=mix((47,55,96),VIOLET,ease(v*1.4)) if v<.66 else mix(VIOLET,CYAN,(v-.66)/.34)
            d.line((1570+k,276,1570+k,282),fill=col,width=1)
        self.text(d,(1570,298),f'{low:.0f}',18,BODY,'mono')
        self.text(d,(1790,298),f'{high:.0f}',18,BODY,'mono',anchor='rt')

    def observe(self,q):
        im=self.background.copy(); d=ImageDraw.Draw(im)
        self.text(d,(88,166),'01 / LIMITED INFORMATION',22,VIOLET,'mono')
        self.text(d,(88,240),'Learning',96,INK,'display')
        self.text(d,(88,351),'where to look.',88,INK,'display')
        self.text(d,(92,499),'Eight unknown objectives.',31,BODY)
        self.text(d,(92,546),'Learn from each returned score.',29,BODY)
        self.text(d,(92,662),'08',78,VIOLET,'display')
        self.text(d,(296,662),'13',78,INK,'display')
        self.text(d,(94,758),'FUNCTIONS',19,BODY,'mono')
        self.text(d,(298,758),'ROUNDS',19,BODY,'mono')
        self.text(d,(92,861),'DIMENSIONS / 2 · 2 · 3 · 4 · 4 · 5 · 6 · 8',18,BODY,'mono')
        self.text(d,(970,173),'F5 / RETURNED OBSERVATIONS',23,CYAN,'mono')
        self.text(d,(970,218),'x1–x2 projection of 4D inputs; height = returned y',20,BODY)
        theta=-.66+.10*ease(q/6)
        self.grid3d(d,theta)
        lo=np.array(self.slice['metadata']['slice_bounds'][0]); hi=np.array(self.slice['metadata']['slice_bounds'][1])
        uv=(self.x[:,:2]-lo)/(hi-lo)*2-1
        pts=self.project(uv,(self.y-250)/750,theta)
        bases=self.project(uv,0,theta)
        n=min(13,1+int(12*ease(q/4.7)))
        if n>1:
            d.line([tuple(p) for p in pts[:n]],fill=mix(VIOLET,BG,.28),width=3)
        for i in range(n):
            p,b=pts[i],bases[i]
            col=CYAN if i==n-1 else VIOLET
            d.line([tuple(p),tuple(b)],fill=mix(col,BG,.65),width=1)
            rr=7 if i==n-1 else 4
            d.ellipse((p[0]-rr,p[1]-rr,p[0]+rr,p[1]+rr),fill=col)
            if i in [0,6,12]:
                self.text(d,(p[0]+18,p[1]-20),f'W{i+1:02d}',20,BODY,'mono')
        self.text(d,(1050,909),'ACTUAL QUERIES. NOT THE FULL LANDSCAPE.',18,BODY,'mono')
        return im

    def model(self,q):
        im=self.background.copy()
        self.surface(im,q)
        d=ImageDraw.Draw(im)
        self.text(d,(88,166),'02 / SURROGATE MODELLING',22,VIOLET,'mono')
        self.text(d,(88,240),'Model the',88,INK,'display')
        self.text(d,(88,342),'unknown.',88,INK,'display')
        methods=[('05','Ridge regression'),('07','Gaussian process + EI'),('13','GP + gradient boosting')]
        for i,(week,label) in enumerate(methods):
            y=511+i*103
            self.text(d,(90,y),f'W{week}',23,VIOLET,'mono')
            self.text(d,(175,y-4),label,28,INK)
            if i<2:
                d.line((116,y+37,116,y+72),fill=GRID,width=2)
        self.text(d,(90,831),'Historical methods above.',23,BODY)
        self.text(d,(90,868),'Display: a new fit to 13 observations.',23,BODY)
        self.text(d,(962,166),'F5 / RETROSPECTIVE 4D GP SLICE',22,CYAN,'mono')
        self.text(d,(930,916),'x3 = 0.899183  /  x4 = 0.849258',20,BODY,'mono')
        self.text(d,(930,947),'SURROGATE MEAN — NOT OBJECTIVE OR UNCERTAINTY',18,BODY,'mono')
        return im

    def control(self,q):
        im=self.background.copy(); d=ImageDraw.Draw(im)
        self.text(d,(88,166),'03 / CONTROLLED LOCAL SEARCH',22,VIOLET,'mono')
        self.text(d,(88,240),'Control where',82,INK,'display')
        self.text(d,(88,339),'to search.',88,INK,'display')
        self.text(d,(92,480),'F5 / THE SETBACK AND RECOVERY',20,BODY,'mono')
        rows=[('W06',self.y[5],BODY,'incumbent'),('W07',self.y[6],CORAL,'global jump'),('W08',self.y[7],CYAN,'local-only GP + EI')]
        for i,(wk,val,col,label) in enumerate(rows):
            yy=538+i*75
            self.text(d,(92,yy),wk,22,col,'mono')
            self.text(d,(185,yy-5),f'{val:.2f}',35,col,'display')
            self.text(d,(354,yy+2),label,22,BODY)
        self.text(d,(92,820),'Hard bound: ±0.018 per coordinate.',26,INK)
        self.text(d,(92,864),'Trust-region-style search, not full TuRBO.',22,BODY)
        self.text(d,(938,166),'W08 / F5 CANDIDATE GEOMETRY',22,CYAN,'mono')
        self.text(d,(938,207),'x1–x2 projection of the regenerated 4D pool',22,BODY)
        theta=-.62+.08*ease(q/7)
        center=(1346,619); scale=334
        self.grid3d(d,theta,center,scale,zscale=0)
        # Actual W8 per-coordinate hard limits, in a slightly larger local view.
        sq=np.array([[-.75,-.75],[.75,-.75],[.75,.75],[-.75,.75],[-.75,-.75]])
        s=self.project(sq,0,theta,center,scale,0)
        d.polygon([tuple(p) for p in s],fill=(27,41,52))
        # Deterministic decimation from the full generated pool; no fabricated candidates.
        pool=self.pool[::29]
        n=max(1,int(len(pool)*ease((q+.5)/2.5)))
        uv=(pool[:n,:2]-self.x[5,:2])/.024
        points=self.project(uv,0,theta,center,scale,0)
        for x,y in points:
            d.ellipse((x-1.4,y-1.4,x+1.4,y+1.4),fill=(74,132,152))
        d.line([tuple(p) for p in s],fill=CYAN,width=2)
        # Anchor and archived W8 query, the latter found exactly in rounded pool.
        a=np.array(center); b=self.project((self.x[7,:2]-self.x[5,:2])/.024,0,theta,center,scale,0)
        d.ellipse((a[0]-6,a[1]-6,a[0]+6,a[1]+6),fill=VIOLET)
        self.text(d,(980,308),'W06 ANCHOR',19,BODY,'mono')
        d.line([(1080,342),(1160,366),tuple(a)],fill=(82,96,132),width=1)
        if q>1.7:
            d.line([tuple(a),tuple(b)],fill=INK,width=2)
            x,y=b
            d.ellipse((x-8,y-8,x+8,y+8),fill=CYAN)
            d.ellipse((x-16,y-16,x+16,y+16),outline=CYAN,width=2)
            d.line([(x,y-20),(x,y-95),(1704,y-95)],fill=CYAN,width=1)
            self.text(d,(1704,y-133),'W08 QUERY',21,CYAN,'mono',anchor='rt')
            self.text(d,(1704,y-99),'returned 413.13',24,INK,anchor='rt')
        self.text(d,(1096,851),f'{len(self.pool):,} candidates retained',25,INK)
        self.text(d,(1096,897),'Shown: every 29th candidate. Seed 105.',20,BODY)
        self.text(d,(1096,931),'Candidate geometry, not an acquisition landscape.',19,BODY)
        return im

    def f5_chart(self,d,rect,week=13,labels=True):
        x0,y0,x1,y1=rect
        yy=lambda v:y1-(float(v)-250)/700*(y1-y0)
        xx=lambda i:x0+i/12*(x1-x0)
        if labels:
            for val in [300,600,900]:
                y=yy(val); d.line((x0,y,x1,y),fill=GRID,width=1)
                self.text(d,(x0-19,y),str(val),18,MUTED,'mono',anchor='rm')
            for i in [0,3,6,9,12]:
                self.text(d,(xx(i),y1+26),f'{i+1:02d}',19,MUTED,'mono',anchor='mt')
        n=max(1,min(13,week))
        points=[(xx(i),yy(self.y[i])) for i in range(n)]
        if n>1:
            d.line(points,fill=(117,126,156),width=3)
        b=self.f5['best_so_far']; stairs=[]
        for i in range(n):
            if i:
                stairs.append((xx(i),yy(b[i-1])))
            stairs.append((xx(i),yy(b[i])))
        if len(stairs)>1:
            d.line(stairs,fill=CYAN,width=4)
        for i,(x,y) in enumerate(points):
            r=6 if i==n-1 else 4
            col=CORAL if i==6 else INK
            d.ellipse((x-r,y-r,x+r,y+r),fill=col)
        if labels and n>=7:
            x,y=points[6]
            self.text(d,(x,y1+60),'W07 setback',19,CORAL,anchor='mt')
        return points

    def measure(self,q):
        im=self.background.copy(); d=ImageDraw.Draw(im)
        self.text(d,(88,166),'04 / OBSERVED PROGRESS',22,VIOLET,'mono')
        self.text(d,(88,216),'Measure what returned.',66,INK,'display')
        week=min(13,1+int(12*ease(q/4.8)))
        value=self.f5['best_so_far'][week-1]
        self.text(d,(92,336),'F5 / BEST OBSERVED',22,CYAN,'mono')
        self.text(d,(88,388),f'{value:.2f}',118,INK,'display')
        self.text(d,(664,446),f'ROUND {week:02d}',21,BODY,'mono')
        self.f5_chart(d,(137,575,930,823),week)
        self.text(d,(136,931),'RAW RETURN',18,BODY,'mono')
        d.line((97,940,121,940),fill=(117,126,156),width=3)
        self.text(d,(395,931),'BEST-SO-FAR',18,CYAN,'mono')
        d.line((356,940,381,940),fill=CYAN,width=4)
        self.text(d,(1065,216),'F1–F8 / OBSERVED BEST-SO-FAR',22,VIOLET,'mono')
        self.text(d,(1065,253),'Independent min–max scales · range 0–1',23,BODY)
        for j,f in enumerate(self.payload['functions']):
            row,col=divmod(j,2); x=1065+col*395; y=319+row*133
            color=CYAN if j==4 else VIOLET
            self.text(d,(x,y),f['id'],23,color,'mono')
            self.text(d,(x+336,y+2),f"{f['dimensions']}D",18,MUTED,'mono',anchor='rt')
            # Each chart uses identical [0,1] height and 13-round width.
            x0,y0,x1,y1=x+6,y+44,x+336,y+102
            d.line((x0,y0,x1,y0),fill=GRID,width=1)
            d.line((x0,y1,x1,y1),fill=GRID,width=1)
            vals=f['normalized_best_so_far']; pts=[]
            for k in range(week):
                xx=x0+(x1-x0)*k/12; yy=y1-(y1-y0)*vals[k]
                if k:
                    pts.append((xx,y1-(y1-y0)*vals[k-1]))
                pts.append((xx,yy))
            if len(pts)>1:
                d.line(pts,fill=color,width=3)
            xx,yy=pts[-1]
            d.ellipse((xx-4,yy-4,xx+4,yy+4),fill=color)
        for x in [1071,1466]:
            self.text(d,(x,841),'W01',16,MUTED,'mono')
            self.text(d,(x+330,841),'W13',16,MUTED,'mono',anchor='rt')
        self.text(d,(1065,878),'1 = best returned value, not a known optimum.',21,BODY)
        self.text(d,(1065,907),'F1 near-zero signal; no cross-function ranking.',20,BODY)
        if week==13:
            self.text(d,(1065,946),'W13: 6 improved · 5 new bests · F2/F8 declined',19,CYAN)
        return im

    def frame(self,t):
        t=float(np.clip(t,0,DURATION-1/FPS))
        self.boxes=[]
        boundaries=[0,6,13,20,30]
        scenes=[self.observe,self.model,self.control,self.measure]
        index=next(i for i in range(4) if boundaries[i]<=t<boundaries[i+1])
        im=scenes[index](t-boundaries[index])
        # A short editorial dissolve, preserving a readable hold in every chapter.
        for b in boundaries[1:-1]:
            if b-.28<=t<b+.28:
                n=boundaries.index(b)
                a=scenes[n-1](b-boundaries[n-1]-.28)
                c=scenes[n](max(0,t-b))
                im=Image.blend(a,c,ease((t-(b-.28))/.56))
                break
        return self.common(im,index,t).convert('RGB')

    def poster(self):
        im=self.background.copy(); self.surface(im,4,poster=True); d=ImageDraw.Draw(im)
        self.text(d,(88,67),'N /  SCIENTIFIC COMPUTING',21,BODY,'mono')
        self.text(d,(1832,67),'AI/ML LEARNING CAPSTONE',21,BODY,'mono',anchor='rt')
        d.line((88,113,1832,113),fill=GRID,width=1)
        self.text(d,(88,181),'BLACK-BOX OPTIMISATION',23,VIOLET,'mono')
        self.text(d,(88,265),'Learning',103,INK,'display')
        self.text(d,(88,383),'where to look.',88,INK,'display')
        self.text(d,(92,531),'From sparse observations',32,BODY)
        self.text(d,(92,581),'to controlled search.',32,BODY)
        self.text(d,(92,707),'08',74,VIOLET,'display')
        self.text(d,(302,707),'13',74,INK,'display')
        self.text(d,(94,795),'OBJECTIVES',18,BODY,'mono')
        self.text(d,(304,795),'ROUNDS',18,BODY,'mono')
        self.text(d,(974,168),'F5 / RETROSPECTIVE GP MEAN SLICE',21,CYAN,'mono')
        self.text(d,(934,907),'4D fit · x3=0.899183 · x4=0.849258',20,BODY,'mono')
        self.text(d,(934,941),'SURROGATE, NOT THE UNKNOWN OBJECTIVE',18,BODY,'mono')
        d.line((88,982,1832,982),fill=GRID,width=1)
        self.text(d,(90,1010),'PYTHON / RIDGE / GP + EI / TRUST REGIONS / GP + BOOSTING',18,BODY,'mono')
        self.text(d,(1830,1008),'F5: 287.43 → 910.48 observed',24,CYAN,anchor='rt')
        return im.convert('RGB')


def encode(r,output):
    command=['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','rawvideo','-pix_fmt','rgb24',
             '-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','medium',
             '-crf','21','-maxrate','2800k','-bufsize','5600k','-pix_fmt','yuv420p',
             '-vf','scale=1920:1080:flags=lanczos,setsar=1','-color_primaries','bt709',
             '-color_trc','bt709','-colorspace','bt709','-threads','2','-movflags','+faststart',
             '-frames:v',str(FPS*DURATION),str(output)]
    with (output.parent/'encode.log').open('w') as log:
        process=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=log)
        try:
            for i in range(FPS*DURATION):
                process.stdin.write(r.frame(i/FPS).tobytes())
                if i%150==0:
                    print(f'Rendered {i}/{FPS*DURATION}',flush=True)
        finally:
            process.stdin.close()
        rc=process.wait()
        if rc:
            raise RuntimeError(f'ffmpeg failed ({rc}); see encode.log')
    return command


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--all',action='store_true')
    parser.add_argument('--preview',action='store_true')
    parser.add_argument('--video',action='store_true')
    parser.add_argument('--output',type=Path,default=ROOT)
    parser.add_argument('--source',type=Path,default=SOURCE)
    args=parser.parse_args(); out=args.output.resolve(); out.mkdir(parents=True,exist_ok=True)
    r=Renderer(args.source)
    (out/'capstone-chart-data.json').write_text(json.dumps(r.payload,separators=(',',':')))
    (out/'surrogate-metadata.json').write_text(json.dumps(r.slice['metadata'],indent=2))
    np.savez_compressed(out/'surrogate-grid.npz',u=r.slice['u'],v=r.slice['v'],mean=r.slice['mean'],queries=r.slice['queries'])
    r.poster().save(out/'optimisation-poster.png',optimize=True)
    r.poster().save(out/'optimisation-poster.webp',quality=92,method=6)
    if args.preview or args.all:
        for sec in [0,4,10,16,19,25,29]:
            r.frame(sec).save(out/f'preview-{sec:02d}.png')
    if args.video or args.all:
        cmd=encode(r,out/'optimisation-showcase.mp4')
        (out/'encode-command.json').write_text(json.dumps(cmd,indent=2))
    if r.layout_violations:
        (out/'layout-violations.json').write_text(json.dumps(r.layout_violations,indent=2))
        raise RuntimeError(f'{len(r.layout_violations)} out-of-frame text labels')
    print('Artifacts rendered. Surrogate range:',r.slice['metadata']['predicted_range'])


if __name__=='__main__':
    main()
