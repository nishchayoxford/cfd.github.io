from pathlib import Path
import importlib
import pytest


def test_replay_comparison_reports_mismatch_instead_of_hiding_it():
    assert Path(__file__).with_name('verify.py').exists(), 'verification implementation missing'
    m = importlib.import_module('verify')
    actual = 'F1: 0.200000-0.300000\nF2: 0.400000-0.500000\n'
    expected = {'F1':'0.200000-0.300000','F2':'0.600000-0.500000'}
    result = m.compare_replay(actual,expected)
    assert result['matched'] == ['F1']
    assert result['mismatched'] == ['F2']
    assert result['all_match'] is False
    assert result['queries']['F2']['archived'] == expected['F2']
    with pytest.raises(ValueError):
        m.compare_replay('nothing',expected)
