#!/usr/bin/env python3
"""Verify the encoded deliverable and numerical/source contracts, without hidden objective calls."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import re
import subprocess
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from capstone_data import SOURCE, build_payload, week8_pool, surrogate_slice
from generate import FONTS

ROOT=Path(__file__).resolve().parent


def compare_replay(log,expected):
    found=dict(re.findall(r'^(F[1-8]): ([0-9.]+(?:-[0-9.]+)+)$',log,re.M))
    if set(found)!=set(expected):
        raise ValueError('Replay must contain one query for every expected function')
    matched=[f for f in expected if found[f]==expected[f]]
    return {'matched':matched,'mismatched':[f for f in expected if f not in matched],
            'all_match':len(matched)==len(expected),
            'queries':{f:{'replayed':found[f],'archived':expected[f]} for f in expected},
            'scope':'Query generation replay only. Returned objective values were not re-evaluated.'}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def verify_public_source(source=SOURCE):
    source = Path(source)
    old = json.loads((ROOT/'evidence-source.sha256.json').read_text())
    now = {str(f.relative_to(source)): sha(f)
           for f in sorted(source.rglob('*')) if f.is_file()}
    assert now == old, 'Bundled public evidence changed'
    return {'unchanged': True, 'files_hashed': len(now), 'hashes': now,
            'scope': 'Bundled public evidence subset; not the original complete repository'}


def main():
    video=ROOT/'optimisation-showcase.mp4'
    probe_cmd=['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)]
    probe=json.loads(subprocess.check_output(probe_cmd,text=True))
    (ROOT/'ffprobe.json').write_text(json.dumps(probe,indent=2))
    stream=next(s for s in probe['streams'] if s['codec_type']=='video')
    video_checks={
        'codec_h264':stream['codec_name']=='h264',
        'pixel_format_yuv420p':stream['pix_fmt']=='yuv420p',
        'full_hd':(stream['width'],stream['height'])==(1920,1080),
        'square_pixels':stream['sample_aspect_ratio']=='1:1',
        '30fps':stream['r_frame_rate']=='30/1',
        'exactly_900_decoded_frames':int(stream['nb_read_frames'])==900,
        'exactly_30_seconds':abs(float(probe['format']['duration'])-30.)<1e-6,
        'under_12_decimal_MB':video.stat().st_size<=12000000,
        'silent':not any(s['codec_type']=='audio' for s in probe['streams']),
    }
    assert all(video_checks.values()),video_checks
    p=build_payload(SOURCE)
    saved=json.loads((ROOT/'capstone-chart-data.json').read_text())
    assert p==saved,'Chart data differs from verified source'
    x=np.array(p['functions'][4]['inputs']); y=np.array(p['functions'][4]['observed'])
    pool=week8_pool(x[:7],y[:7]); sl=surrogate_slice(x,y)
    stored=np.load(ROOT/'surrogate-grid.npz')
    normalized=[np.array(f['normalized_best_so_far']) for f in p['functions']]
    numerical={
        'rounds':p['rounds'],'functions':len(p['functions']),'observations':p['observation_count'],
        'dimensions':[f['dimensions'] for f in p['functions']],
        'cumulative_input_and_output_prefixes_exact':p['all_cumulative_prefixes_exact'],
        'all_incumbents_monotonic':all(np.min(np.diff(f['best_so_far']))>=0 for f in p['functions']),
        'all_normalized_in_0_1':all(np.min(a)>=0 and np.max(a)<=1 for a in normalized),
        'all_final_normalized_incumbents_one_by_definition':all(a[-1]==1. for a in normalized),
        'no_absolute_epsilon_corrupts_F1_normalization':p['functions'][0]['normalized_best_so_far'][2]>.99,
        'full_payload_exact_to_source':p==saved,
        'F5_final_return':float(y[-1]), 'F5_W13_vs_W12_percent':p['functions'][4]['w13_vs_w12_percent'],
        'F5_W13_vs_W1_ratio':p['functions'][4]['w13_vs_w1_ratio'],
        'best_observed_weeks':[f['best_week'] for f in p['functions']],
        'improvements_W2_through_W13':p['improvement_counts'],
        'W13':p['final_round'],
        'W8_candidate_count':len(pool),
        'W8_all_4D_candidates_within_point018':bool(np.max(np.abs(pool-x[5]))<=.018),
        'W8_archived_query_present_after_six_decimal_rounding':bool(np.min(np.linalg.norm(np.round(pool,6)-x[7],axis=1))==0.),
        'surrogate_recomputed_grid_exact':bool(np.array_equal(sl['mean'],stored['mean'])),
        'surrogate_fixed_hidden_dimensions_exact':bool(np.array_equal(stored['queries'][:,2:],np.tile(x[-1,2:],(len(stored['queries']),1)))),
    }
    for key,val in numerical.items():
        if isinstance(val,bool): assert val,key
    source_integrity=verify_public_source()
    replay=compare_replay((ROOT/'evidence/week13-replay.txt').read_text(),
                          {f['id']:'-'.join(f'{v:.6f}' for v in f['inputs'][-1]) for f in p['functions']})
    # Decode the actual compressed movie, including the final displayed frame.
    frames=[('start',0),('middle',450),('end',899)]
    for name,number in frames:
        subprocess.run(['ffmpeg','-y','-v','error','-i',str(video),'-vf',f'select=eq(n\\,{number})',
                        '-vsync','0','-frames:v','1',str(ROOT/f'encoded-{name}.png')],check=True)
    sheet=Image.new('RGB',(1920,440),(18,20,27)); d=ImageDraw.Draw(sheet)
    font=ImageFont.truetype(FONTS['mono'],18)
    d.text((20,16),'ENCODED FRAME REVIEW / 1920 × 1080 / H.264 / 30 FPS',font=font,fill=(232,234,240))
    for i,(name,number) in enumerate(frames):
        image=Image.open(ROOT/f'encoded-{name}.png').convert('RGB')
        assert image.size==(1920,1080)
        image.thumbnail((624,351),Image.Resampling.LANCZOS)
        sheet.paste(image,(16+i*640,53))
        d.text((20+i*640,413),f'{name.upper()} / frame {number:03d} / {number/30:.3f}s',font=font,fill=(174,179,194))
    sheet.save(ROOT/'encoded-contact-sheet.jpg',quality=93,subsampling=0)
    files=['optimisation-showcase.mp4','optimisation-poster.webp','optimisation-poster.png',
           'capstone-chart-data.json','surrogate-metadata.json','surrogate-grid.npz',
           'encoded-contact-sheet.jpg','encoded-start.png','encoded-middle.png','encoded-end.png',
           'generate.py','capstone_data.py','verify.py','test_data.py','test_render.py','test_verify.py',
           'EVIDENCE.md','README.md','LICENSE','test_portability.py',
           'evidence-source.sha256.json','evidence/week13-replay.txt',
           'ffprobe.json','requirements.lock.txt']
    checksums={name:{'sha256':sha(ROOT/name),'bytes':(ROOT/name).stat().st_size} for name in files if (ROOT/name).exists()}
    manifest={
        'deliverable':'Learning where to look — public AI/ML learning capstone',
        'source_repository':p['source_repository'],
        'source_integrity':source_integrity,
        'video_checks':video_checks,'ffprobe':probe,'numerical_assertions':numerical,
        'week13_replay':replay,
        'replay_note':'F1–F7 match exactly; F8 differs. Cause unresolved. No hidden objective evaluated.',
        'display_surrogate':sl['metadata'],
        'environment':{'python':sys.version,'packages':{n:importlib.metadata.version(n) for n in ['numpy','scipy','Pillow','scikit-learn','pytest']}},
        'decoded_contact_frames':[{'name':name,'frame_index':i,'seconds':i/30} for name,i in frames],
        'visual_review':'Inspect the regenerated encoded contact sheet; script checks do not constitute a new human visual review.',
        'bundled_source_replay':{
            n:sha(ROOT/n)==sha(ROOT/'replay-check'/n)
            for n in ['optimisation-poster.png','optimisation-poster.webp','capstone-chart-data.json','surrogate-grid.npz']
            if (ROOT/'replay-check'/n).exists()},
        'sha256':checksums,
    }
    (ROOT/'verification-manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'video':video_checks,'video_bytes':video.stat().st_size,
                      'bundled_source_unchanged':source_integrity['unchanged'],'numerical':numerical,'replay':replay},indent=2))


if __name__=='__main__':
    main()
