"""Rendering contracts tested before the renderer is implemented."""
from pathlib import Path
import importlib
import numpy as np


def test_film_scene_frames_are_full_hd_nonblank_with_safe_text():
    assert Path(__file__).with_name('generate.py').exists(), 'cinematic renderer not implemented'
    m = importlib.import_module('generate')
    r = m.Renderer()
    for t in [0., 5., 10., 15., 19., 23., 29.9666667]:
        image = r.frame(t)
        assert image.size == (1920,1080)
        assert image.mode == 'RGB'
        assert np.asarray(image).std() > 12
    assert r.layout_violations == []
    assert m.FPS * m.DURATION == 900
    poster = r.poster()
    assert poster.size == (1920,1080)
    assert r.layout_violations == []


def test_data_annotations_do_not_collide_with_cloud_or_axis_labels():
    assert Path(__file__).with_name('generate.py').exists()
    r = importlib.import_module('generate').Renderer()
    r.frame(16.)
    anchor = next(box for label,box in r.boxes if 'W06 ANCHOR' == label)
    assert anchor[3] < 380, 'anchor annotation must stay above the projected cloud'
    r.frame(29.)
    setback = next(box for label,box in r.boxes if label == 'W07 setback')
    ticks = [box for label,box in r.boxes if label in ['01','04','07','10','13']]
    for tick in ticks:
        assert setback[3] < tick[1] or tick[3] < setback[1] or setback[2] < tick[0] or tick[2] < setback[0]
